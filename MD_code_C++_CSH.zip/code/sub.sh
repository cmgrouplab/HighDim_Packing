#!/bin/bash
#SBATCH -J md
#SBATCH -p cpu
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH --error=%J.err
#SBATCH --output=%J.out

cd /fs0/home/70207490/SpherePacking/
./a.out input.txt
