#!/bin/bash
#SBATCH -J md5D
#SBATCH -p cpu
#SBATCH -n 20
#SBATCH --error=%J.err
#SBATCH --output=%J.out

ncpus=20

cd /fs0/home/70207490/SpherePacking/

module load openmpi/gcc-4.1.1

mpiexec -n ${ncpus} a5D.out input_5D_r1.txt
