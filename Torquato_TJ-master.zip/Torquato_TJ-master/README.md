# Torquato_TJ
Implementation of the Torquato-Jiao Sequential Linear Programming Algorithm
