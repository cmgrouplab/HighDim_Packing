//TimerClass.h: Structure of the TimerClass class

#ifndef TIMERCLASSHEADER

class TimerClass {
 public:
  double timePassed;

  void Start();
  void End();
  void Display();
 private:
  time_t startTime;
  time_t endTime;
};

#define TIMERCLASSHEADER
#endif
