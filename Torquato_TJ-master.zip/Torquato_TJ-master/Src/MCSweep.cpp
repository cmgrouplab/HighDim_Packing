//MCSweep.cpp
//Implementation of the Monte Carlo Sweep

#include <iostream>
#include <string>
#include <gsl/gsl_rng.h>
#include <math.h>

#include "main.h"
#include "MCSweep.h"

using namespace std;

void MC_Init()
{
  mc_dispLimit = radii[0]; //In local coords

  return;
}

double MC_Sweep(int numTries)
//Try N MC moves
//keep track of the success rate
{
  cout << "MC_Sweep()\n";
  inverseLambdas = getInverse(lambdas);
  int numSuccess = 0;
  double mc_maxDisp = 0.0;
  for (int i = 0 ; i < numTries ; i++) {
    //Pick a random sphere:
    int thisSphere = floor(N*gsl_rng_uniform_pos(RNG));
    //cout << "try sphere " << thisSphere << endl;
    double thisDisp = MC_Move(thisSphere);
    if (thisDisp > 0.0) {
      numSuccess++;
      if (thisDisp > mc_maxDisp) {
	mc_maxDisp = thisDisp;
      }
    }
  }

  double mc_accRate = (double) numSuccess / (double) numTries;
  //Print results:
  cout << "  MC Sweep Summary:\n";
  cout << "    mc_accRate   = " << numSuccess << " / " << numTries << " = " << mc_accRate << "\n";
  cout << "    mc_dispLimit = " << mc_dispLimit << endl;
  //Rescale maximum move:
  MC_AdjustDispLimit(mc_accRate);

  return(mc_maxDisp);
}


double MC_Move(int i)
//Try to move particle i
//Return resulting displacement (0 if failure)
{
  double *posG = new double[dim];
  double *oldPosL = new double[dim];
  double thisMoveDist = 0.0;
  //cout << "    Move:\n";
  for (int d = 0 ; d < dim ; d++) {
    //Store old position:
    oldPosL[d] =  localCoords[i*dim + d];
  }

  for (int j = 0 ; j < dim ; j++) {
    //Find global:
    posG[j] = 0.0;
    for (int d = 0 ; d < dim ; d++) {
      posG[j] += gsl_matrix_get(lambdas,j,d) * oldPosL[d];
    }
    //Move to a new position:
    double thisMove = mc_dispLimit * (2.0*gsl_rng_uniform_pos(RNG) - 1.0);
    //cout << "      " << posG[j] << " + " << thisMove << endl;
    posG[j] += thisMove;
    thisMoveDist += thisMove*thisMove;
  }
  thisMoveDist = sqrt(thisMoveDist);

  //Find new local position:
  for (int j = 0 ; j < dim ; j++) {
    int k = i*dim+j; //We'll use this a few times in this loop:
    localCoords[k] = 0.0;
    for (int d = 0 ; d < dim ; d++) {
      localCoords[k] += gsl_matrix_get(inverseLambdas,j,d) * posG[d];
    }
    //Put back in the FC:
    if (localCoords[k] > 1.0)
      localCoords[k] -= 1.0;
    else if (localCoords[k] < 0.0)
      localCoords[k] += 1.0;
  }

  //Check for overlaps (crude for now because this shouldn't take long compared to the LP)
  bool foundOverlap = false;
  if (overBoxes > 0) {
    int indexNum = int(pow(2.0*double(overBoxes) +1.0,dim));
    int selfIndexSkip = (indexNum -1)/2;              // this number is the self-image in the same unit cell
    for (int j = 0 ; j < N ; j++) {
      for (int k=0; k < indexNum; k++) {
	if (j==i && k == selfIndexSkip) {    // skip self image in same box
	  continue;
	}
	int quotient = k;
	for (int d=0; d<dim; d++) {
	  int remain = quotient % (2*overBoxes +1);
	  double shift = double(remain - overBoxes);        // this is the image that is shift lattice cells over
	  distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d] + shift;
	  quotient = quotient/(2*overBoxes +1);
	}

	double dist = getGlobalLength(distTempL);

	if (dist < radii[i] + radii[j]) {             // note that this is for additive diameters!
	  foundOverlap = true;
	  //cout << "    Overlap with " << j << endl;
	  break;
	}
      }
    }
  }
  else { //No overBoxes -- use L/2 method
    for (int j = 0 ; j < N ; j++) {
      if (i == j) continue; //Don't check self-overlap with nearest image!
      for (int d=0; d<dim; d++) {
	distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d];
	if (distTempL[d] > 0.5) {
	  distTempL[d] = distTempL[d] - 1.0;
	}
	else if (distTempL[d] < -0.5) {
	  distTempL[d] = distTempL[d] + 1.0;
	}
      }

      double dist = getGlobalLength(distTempL);

      if (dist < radii[i] + radii[j]) {             // note that this is for additive diameters!
	foundOverlap = true;
	//cout << "    Overlap with " << j << endl;
	break;
      }
    }
  }

  if (foundOverlap) {//Reset position:
    for (int d = 0 ; d < dim ; d++) {
      localCoords [i*dim+d] = oldPosL[d];
      thisMoveDist = 0.0;
    }
  }

  //Deallocate:
  delete [] posG;
  delete [] oldPosL;
  
  return(thisMoveDist);
}


void MC_AdjustDispLimit(double accRate)
{
  double lambda = 0.5; //Relaxation factor (to prevent large overshoot)
  mc_dispLimit *= (1.0 - lambda) + lambda / (2.0 * (1.0 - accRate));
  if (mc_dispLimit > 2.0*radii[0]) {//put a limit on it (kinda arbitrary)
    mc_dispLimit = 2.0*radii[0];
  }
  else if (mc_dispLimit < 1.0e-12) {
    mc_dispLimit = 1.0e-12;
  }

  return;
}
