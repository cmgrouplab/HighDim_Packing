//MCSweep.h
//Header for MC Sweep Functions

#ifndef MCSWEEPHEADER
#define MCSWEEPHEADER

//Variables:
extern double mc_dispLimit;

void   MC_Init();                          //finds a reasonable value for mc_maxDisp to start
double MC_Sweep(int numTries);             //Perform a sweep; return mc_maxDisp, the farthest anyone went
double MC_Move(int i);                     //Try to move particle i; return displacement (= 0 if failed)
void   MC_AdjustDispLimit(double accRate);

#endif
