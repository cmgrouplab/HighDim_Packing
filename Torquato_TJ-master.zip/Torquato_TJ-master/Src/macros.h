//Some macros:
#define ERR_NOINPUTFILE      1 //Abort because a correct input file wasn't given
#define ERR_BADGUROBILICENSE 2 //Abort because Gurobi's license didn't work


#define COUT_PRECISION       12
