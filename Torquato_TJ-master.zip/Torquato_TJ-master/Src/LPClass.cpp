//LPClass.cpp
//Implementation of the Linear Programming class
//Included from main.cpp

#include <gsl/gsl_math.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_sort_vector.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_linalg.h>
#include <fstream>
#include <sstream>
//Libraries as used on Steve's machines:
#ifdef STEVE_MACHINE
#include <boost/filesystem.hpp> //Steve's systems
//#include <glpk.h>  //On Steve's systems
#endif
//molecule:
#ifdef MOLECULE_MACHINE
#include <boost/filesystem.hpp> //Steve's systems
//#include <glpk.h>  //On Steve's systems
#endif
//Libraries as used on della:
#ifdef DELLA_MACHINE
#include <boost/filesystem/operations.hpp> //della
//#include <glpk/glpk.h> //For use on della
#endif

//========================================================
// Libraries necessary for LPClass:

#ifdef GLPK_OPTIMIZE
  #ifdef STEVE_MACHINE
    #include <glpk.h>  //On Steve's systems
  #endif
  //Libraries as used on della:
  #ifdef DELLA_MACHINE
    #include <glpk/glpk.h>
  #endif
  //Libraries on positron:
  #ifdef POSITRON_MACHINE
    #include <glpk/glpk.h>
  #endif
  #ifdef MOLECULE_MACHINE
    #include <glpk.h> //For use on della
  #endif
#endif

#ifdef GUROBI_OPTIMIZE
  #include <gurobi_c++.h>
#endif

#ifdef CPLEX_OPTIMIZE
  #include <ilcplex/ilocplex.h>
#endif

#include "main.h"
#include "LPClass.h"

using namespace std;

//////////////////////////////////////////////////////
//CONSTRUCTOR AND DESTRUCTOR:

LPClass::LPClass()
{
  //Values & things:
  epsilonNum = strictJam == 1 ? (dim*(dim +1))/2 : 1; //epsilon is a scalar for collective jamming!
  numVar = epsilonNum + dim*N;

  tempVec1            = new double[dim];
  tempVec2            = new double[dim];
  maxMoveVals         = new double[dim];
  oldLambdasNewLocals = new double[dim];
  deltaLocalCoords    = new double[dim];
  updateLambdas = gsl_matrix_calloc(dim,dim);
  updateTemp    = gsl_matrix_calloc(dim,dim);

  //Set CPLEX stuff to null in case it doesn't get used:
#ifdef CPLEX_OPTIMIZE
  cplex_sol        = NULL;
  cplex_varUsed    = NULL;
  cplex_sphereToLP = NULL;
  cplex_lpToSphere = NULL;
#endif


  //Set solverInt:
  if (solver == "GLPK")
    solverInt = SOLVER_GLPK;
  else if (solver == "Gurobi")
    solverInt = SOLVER_GUROBI;
  else if (solver == "CPLEX")
    solverInt = SOLVER_CPLEX;
  else
    solverInt = SOLVER_INVALID;

  //Set haveSolver to reflect if the solver chosen was included at compile-time
  haveSolver=false;
  switch(solverInt) {
#ifdef GLPK_OPTIMIZE
  case SOLVER_GLPK :
    haveSolver = true;
    break;
#endif
#ifdef GUROBI_OPTIMIZE
  case SOLVER_GUROBI :
    haveSolver = true;
    break;
#endif
#ifdef CPLEX_OPTIMIZE
  case SOLVER_CPLEX :
    haveSolver = true;
    cplex_sol        = new double[numVar]; //Allocate here to keep memory in better shape
    cplex_varUsed    = new bool  [numVar];
    cplex_sphereToLP = new int   [numVar];
    cplex_lpToSphere = new int   [numVar];
    break;
#endif
  default :
    cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
  }


#ifdef GUROBI_OPTIMIZE
  gEnv=NULL;
  gModel=NULL;
  gVar=NULL;
  gConstr=NULL;
  gExpr=NULL;
#endif

#ifdef CPLEX_OPTIMIZE
  cplex_env   = NULL;
  cplex_model = NULL;
  cplex_obj   = NULL;
  cplex_var   = NULL;
  cplex_con   = NULL;
  cplex       = NULL;
  //cplex_sol   = NULL; //Allocated above
#endif

}

LPClass::~LPClass()
{
  cout<<"LPClass::~LPClass()"<<endl;

  delete [] tempVec1;
  delete [] tempVec2;
  delete [] maxMoveVals;
  delete [] oldLambdasNewLocals;
  delete [] deltaLocalCoords;
  gsl_matrix_free(updateLambdas);
  gsl_matrix_free(updateTemp);


#ifdef GUROBI_OPTIMIZE
  cout<<"gEnv"<<flush;
  if (gEnv) {
    cout<<"--delete"<<flush;
    delete gEnv;
    gEnv=NULL;
  }
  cout<<"\ngModel"<<flush;
  if (gModel) {
    cout<<"--delete"<<flush;
    delete gModel;
    gModel=NULL;
  }
  cout<<"\ngVar"<<flush;
  if (gVar) {
    cout<<"--delete"<<flush;
    delete [] gVar;
    gVar=NULL;
  }
  cout<<"\ngExpr"<<flush;
  if (gExpr) {
    cout<<"--delete"<<flush;
    delete [] gExpr;
    gExpr=NULL;
  }
#endif

#ifdef CPLEX_OPTIMIZE
  if (cplex_env) {
    cplex_env->end();
    delete cplex_env;
    cplex_env = NULL;
  }
  //Fill out here
  if (cplex_sol) {
    delete [] cplex_sol;
    cplex_sol = NULL;
  }
  if (cplex_varUsed) {
    delete [] cplex_varUsed;
    cplex_varUsed = NULL;
  }
  if (cplex_sphereToLP) {
    delete [] cplex_sphereToLP;
    cplex_sphereToLP = NULL;
  }
  if (cplex_lpToSphere) {
    delete [] cplex_lpToSphere;
    cplex_lpToSphere = NULL;
  }
#endif

  cout<<endl;
}




void LPClass::LPRoutine(int lpIters,
		       int maxSize)
{
  if (!haveSolver) {
    cerr<<" You didn't specify a solver that you have -- no LP solve will be performed."<<endl;
    return;
  }

  Initialize();
  Generate(maxSize);
  Import();
  Solve(); //Sets solverStatus
  Export(lpIters);
  Cleanup();

  return;
}



//////////////////////////////////////////////////////
//INITIALIZE OBJECT VARIABLES


void LPClass::Initialize()
{
  numConstr=0;    //Number of constraints in this problem
  numLHS=0;       //Number of LHS entries in the constraint matrix
  coeffVal = 0.0;
  dist = 0.0;
  countCons = 0;
  countRows = 0;
  epsilonColTrack = 0;
  success = 0;
  ifResize = 0;
  maxMoveVal = 0.0;
  greatestMaxMoveVal = 0.0;
  epsilonVal = 0.0;
  updateTempVal = 0.0;
  latVol = 0.0;
  solverStatus = 0;
  warmUpParam = false;
  warmUpReturn = 0;

  gIterCount=0;


  for (int i=0; i<dim; i++) {
    tempVec1[i] = 0.0;
    tempVec2[i] = 0.0;
    maxMoveVals[i] = 0.0;
    oldLambdasNewLocals[i] = 0.0;
    deltaLocalCoords[i] = 0.0;
    for (int j=0; j<dim; j++) {
      gsl_matrix_set(updateLambdas,i,j,0.0);
      gsl_matrix_set(updateTemp,i,j,0.0);
    }
  }

  return;
}


//////////////////////////////////////////////////////
//GENERATE THE LP


void LPClass::Generate(int maxSize)
//Generates the LP constraints and imports them into the solver of choice (maxSize is the maximum number of constraints)
{
  //cout << "  Generate Constraints" << endl;
  if (useNNL) {Generate_NNL  (maxSize);}
  else        {Generate_NoNNL(maxSize);}

  return;
}


void LPClass::Generate_NNL(int maxSize)
//NOTE: ia,ja,ar START AT INDEX 1 (NOT ZERO!)
{
  // NNL variables
  NeighborNode *addressTempNNL = 0;

  // LP solver variables
  //Each sphere pair constraint equation has the following entries:
  //  dim entries for each sphere's displacement (total = 2*dim)
  //  epsilonNum entries for the deforming box
  //    (If collective jamming, then this is a scalar)
  const int arraySize = strictJam ? 
    (2*dim + epsilonNum)*maxSize+dim+1 : //+dim for the bulk strain constraint (Trace <= 0), and +1 because the arrays start at index 1
    (2*dim + epsilonNum)*maxSize    +1;  //Don't worry--epsilonNum=1 if strictJam==0 

  //cout << "Allocate for " << arraySize << " entries" << endl;
  ia     = new int   [arraySize];
  ja     = new int   [arraySize];
  ar     = new double[arraySize];

  ineq          = new int   [maxSize];
  bounds        = new double[maxSize];
  constrSphere1 = new int   [maxSize];
  constrSphere2 = new int   [maxSize];
  for (int i=0 ; i<maxSize   ; i++) {
    ineq[i] = 0;
    bounds[i] = 0.0;
    constrSphere1[i] = -1;
    constrSphere2[i] = -1;
  }
  for (int i=0 ; i<arraySize ; i++) {
    ia[i] = 0;
    ja[i] = 0;
    ar[i] = 0.0;
  }

  //Add the bulk strain constraint:
  if (strictJam == 1)
    ApplyBulkStrainConstraint();

  //use L/2 method to calc distance
  //int startIndex = 1;
  int warnNegSep=0; //Keep track of how many overlaps exist before the solve...
  for (int i=0; i<N; i++) {
    addressTempNNL = neighborListDelta[i];
    while (addressTempNNL) {
      const int j = addressTempNNL->index;

      // continue if j < i, i.e., only perform NNL calcs once for each contact
      if (j < i) {
	addressTempNNL = addressTempNNL->next;
	continue;
      }

      for (int d=0; d<dim; d++) {
	distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d];
	if (distTempL[d] > 0.5) {
	  distTempL[d] = distTempL[d] - 1.0;
	}
	else if (distTempL[d] < -0.5) {
	  distTempL[d] = distTempL[d] + 1.0;
	}
      }

      dist = getGlobalLength(distTempL);
      double distSq = dist*dist;

      if (dist <= radii[i] + radii[j] + delta) {//If the two spheres are within influence sphere-range
	//cout << "   Interaction: " << i << " & " << j << endl;
	countRows++;

	//
	//
	//  ---Here's how all the "temps" stack up:---
	//
	//  distTempL * Lambdas_T * Lambdas * distTempL 
	//                          \_________________/
	//                               tempVec1
	//              \_____________________________/
	//                         tempVec2
	//  \_________________________________________/
	//        Global distance squared btwn 
	//           sphere centers i and j
	//
	//

	// calc tempVec1 (Lambdas*distTempL)
	// and 
	for (int l=0; l<dim; l++) {
	  tempVec1[l] = 0.0;
	  for (int d=0; d<dim; d++) {
	    tempVec1[l] += gsl_matrix_get(lambdas,l,d)*distTempL[d];
	  }
	}

	// calc tempVec2 (Lambdas_T*tempVec1)
	for (int l=0; l<dim; l++) {
	  tempVec2[l] = 0.0;
	  for (int d=0; d<dim; d++) {
	    tempVec2[l] += gsl_matrix_get(lambdas,d,l)*tempVec1[d];
	  }
	}

	// input the epsilon coeffs
	if (strictJam == 0) {//Simple for collective jamming!
	  //#check
	  ar[++countCons] = distSq; //Global distance squared between the spheres
	  ia[  countCons] = countRows;
	  ja[  countCons] = 1;
	}
	else if (strictJam == 1) {
	  epsilonColTrack = 1;
	  for (int d=0; d<dim; d++) {//First index of the epsilon
	    ar[++countCons] = tempVec1[d]*tempVec1[d];
	    ia[  countCons] = countRows;
	    ja[  countCons] = epsilonColTrack;
	    epsilonColTrack = epsilonColTrack +1;
	    for (int l=d +1; l<dim; l++) {//Second index of the epsilon
	      ar[++countCons] = 2*tempVec1[d]*tempVec1[l];
	      ia[  countCons] = countRows;
	      ja[  countCons] = epsilonColTrack;
	      epsilonColTrack = epsilonColTrack +1;
	    }
	  }
	}



	// input the deltaR coeffs (order is: x1,x2,y1,y2,z1,z2...)
	for (int d=0; d<dim; d++) {
	  ar[++countCons] = tempVec2[d];
	  ia[  countCons] = countRows;
	  ja[  countCons] = epsilonNum + i*dim +d +1;
	  ar[++countCons] = -1.0*tempVec2[d];
	  ia[  countCons] = countRows;
	  ja[  countCons] = epsilonNum + j*dim +d +1;
	}

	// calc bounds (i.e., RHS of constraint)
	coeffVal = ((radii[i] + radii[j])*(radii[i] + radii[j])) - distSq;    // note this is for additive diameters!
	//for (int d=0; d<dim; d++) {
	//coeffVal -= distTempL[d]*tempVec2[d];
	//}
	ineq  [countRows] = INEQ_GREATER_THAN;
	bounds[countRows] = coeffVal/2.0;
	constrSphere1[countRows] = i+1;
	constrSphere2[countRows] = j+1;
	if (bounds[countRows] > 0.0) {
	  warnNegSep++;
	}

	//Check:
	//int lastIndex = countCons;
	//cout << "  Constraint " << countRows+1 << ":" << endl;
	//for (int checkIndex = startIndex ; checkIndex < lastIndex ; checkIndex++) {
	//cout << "A(" << ia[checkIndex] << "," << ja[checkIndex] << ") = " << ar[checkIndex] << endl;
	//}
	//cout << "b(" << countRows << ") = " << bounds[countRows] << endl;
	//startIndex = lastIndex;
      }

      addressTempNNL = addressTempNNL->next;
    }
  }

  cout << "  Generated " << countRows << " constraints, " << countCons << " entries" << endl;
  numConstr = countRows;
  numLHS    = countCons;

  if (warnNegSep>0)
    cerr<<"WARNING: starting configuration has "<<warnNegSep<<" overlaps.\n";

  return;
}


void LPClass::Generate_NoNNL(int maxSize)
{
  // box variables
  int indexNum = int(pow(2.0*double(overBoxes) +1.0,dim));
  int selfIndexSkip = (indexNum -1)/2;             // this number is the self-image in the same unit cell
  double shift = 0.0;
  int quotient = 0;
  int remain = 0;

  // LP solver variables
  maxSize = ((N*(N+1))/2)*indexNum -1;             // overkill if delta is not large. But if it is large, this is barely sufficient!
  const int arraySize = strictJam ? 
    (2*dim + epsilonNum)*maxSize+dim+1 : //+dim for the bulk strain constraint (Trace <= 0), and +1 because the arrays start at index 1
    (2*dim + epsilonNum)*maxSize    +1;  //Don't worry--epsilonNum=1 if strictJam==0


  cout << "  ia,ja,ar,... arraySize = " << arraySize << endl;
  ia     = new int   [arraySize];
  ja     = new int   [arraySize];
  ar     = new double[arraySize];

  ineq          = new int   [maxSize];
  bounds        = new double[maxSize];
  constrSphere1 = new int[maxSize];
  constrSphere2 = new int[maxSize];
  for (int i=0 ; i<maxSize   ; i++) {
    ineq[i] = 0;
    bounds[i] = 0.0;
  }
  for (int i=0 ; i<arraySize ; i++) {
    ia[i] = 0;
    ja[i] = 0;
    ar[i] = 0.0;
  }

  //Add the bulk strain constraint:
  //  (Unneeded in collective jamming because the strain variable is a scalar)
  if (strictJam==1)
    ApplyBulkStrainConstraint();
  int warnNegSep=0; //Keep track of how many overlaps exist before the solve...
  for (int i=0; i<N; i++) {
    for (int j=i; j<N; j++) {
      for (int k=0; k < indexNum; k++) {
	if (j==i && k == selfIndexSkip) {    // skip self image in same box
	  continue;
	}
	quotient = k;
	for (int d=0; d<dim; d++) {
	  remain = quotient % (2*overBoxes +1);
	  shift = double(remain - overBoxes);        // this is the image that is shift lattice cells over
	  distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d] + shift;
	  quotient = quotient/(2*overBoxes +1);
	}

	dist = getGlobalLength(distTempL);
	double distSq = dist*dist;

	if (dist <= radii[i] + radii[j] + delta) {
	  //cout << "   Interaction: " << i << " & " << j << endl;
	  countRows++;

	  //
	  //
	  //  ---Here's how all the "temps" stack up:---
	  //
	  //  distTempL * Lambdas_T * Lambdas * distTempL 
	  //                          \_________________/
	  //                               tempVec1
	  //              \_____________________________/
	  //                         tempVec2
	  //  \_________________________________________/
	  //        Global distance squared btwn 
	  //           sphere centers i and j
	  //
	  //

	  // calc tempVec1 (Lambdas*distTempL)
	  // and 
	  for (int l=0; l<dim; l++) {
	    tempVec1[l] = 0.0;
	    for (int d=0; d<dim; d++) {
	      tempVec1[l] += gsl_matrix_get(lambdas,l,d)*distTempL[d];
	    }
	  }

	  // calc tempVec2 (Lambdas_T*tempVec1)
	  for (int l=0; l<dim; l++) {
	    tempVec2[l] = 0.0;
	    for (int d=0; d<dim; d++) {
	      tempVec2[l] += gsl_matrix_get(lambdas,d,l)*tempVec1[d];
	    }
	  }

	  // input the epsilon coeffs
	  if (strictJam == 0) {//Simple for collective jamming!
	    //#check
	    ar[++countCons] = distSq; //Global distance squared between the spheres
	    ia[  countCons] = countRows;
	    ja[  countCons] = 1;
	  }
	  else if (strictJam == 1) {
	    epsilonColTrack = 1;
	    for (int d=0; d<dim; d++) {//First index of the epsilon
	      ar[++countCons] = tempVec1[d]*tempVec1[d];
	      ia[  countCons] = countRows;
	      ja[  countCons] = epsilonColTrack;
	      epsilonColTrack = epsilonColTrack +1;
	      for (int l=d +1; l<dim; l++) {//Second index of the epsilon
		ar[++countCons] = 2*tempVec1[d]*tempVec1[l];
		ia[  countCons] = countRows;
		ja[  countCons] = epsilonColTrack;
		epsilonColTrack = epsilonColTrack +1;
	      }
	    }
	  }



	  // input the deltaR coeffs (order is: x1,x2,y1,y2,z1,z2...)
	  if (i!=j) {              // if i==j, then deltaR coeffs are immaterial b/c coeff*(deltaR1 - deltaR1) = 0
	    for (int d=0; d<dim; d++) {
	      ar[++countCons] = tempVec2[d];
	      ia[  countCons] = countRows;
	      ja[  countCons] = epsilonNum + i*dim +d +1;
	      ar[++countCons] = -1.0*tempVec2[d];
	      ia[  countCons] = countRows;
	      ja[  countCons] = epsilonNum + j*dim +d +1;
	    }
	  }
	  else {              // BUT WE STILL NEED TO HOLD THEIR PLACES FOR GUROBI!
	    for (int d=0; d<dim; d++) {
	      ar[++countCons] = 0.0;
	      ia[  countCons] = countRows;
	      ja[  countCons] = epsilonNum + i*dim +d +1;
	      ar[++countCons] = 0.0;
	      ia[  countCons] = countRows;
	      ja[  countCons] = epsilonNum + j*dim +d +1;
	    }
	  }

	  // calc bounds (i.e., RHS of constraint)
	  coeffVal = ((radii[i] + radii[j])*(radii[i] + radii[j])) - distSq;    // note this is for additive diameters!
	  //for (int d=0; d<dim; d++) {
	  //coeffVal -= distTempL[d]*tempVec2[d];
	  //}
	  ineq  [countRows] = INEQ_GREATER_THAN;
	  bounds[countRows] = coeffVal/2.0;
	  constrSphere1[countRows] = i+1;
	  constrSphere2[countRows] = j+1;
	  if (bounds[countRows] > 0.0) {
	    warnNegSep++;
	  }

	  //Check:
	  //int lastIndex = countCons;
	  //cout << "  Constraint " << countRows+1 << ":" << endl;
	  //for (int checkIndex = startIndex ; checkIndex < lastIndex ; checkIndex++) {
	  //cout << "A(" << ia[checkIndex] << "," << ja[checkIndex] << ") = " << ar[checkIndex] << endl;
	  //}
	  //cout << "b(" << countRows << ") = " << bounds[countRows] << endl;
	  //startIndex = lastIndex;
	}
      }
    }
  }

  cout << "  Generated " << countRows << " constraints, " << countCons << " LHS entries" << endl;
  numConstr = countRows;
  numLHS    = countCons;

  if (warnNegSep>0)
    cerr<<"WARNING: starting configuration has "<<warnNegSep<<" overlaps.\n";

  return;
}


void LPClass::ApplyBulkStrainConstraint()
//
//  (For Strict Jamming only)
//
//The trace of the diagonal strain terms must be non-positive.
//NOTE: Since all of the constraints are uniformly input as
//"GREATER THAN OR EQUAL TO" inequalities, e.g.,
//a1x1 + a2x2 + ... >= b, 
//then the correct way to pose this is as
//-Tr(E) >= 0
//instead of 
// Tr(E) <= 0
//That's why ar[countCons] = -1.0, not +1.0
{
  //Add a term for each diagonal strain component:
  countRows++;
  ineq  [countRows] = INEQ_GREATER_THAN;
  bounds[countRows] = 0.0;
  constrSphere1[countRows] = 0;
  constrSphere2[countRows] = 0;
  int epsilonIndex = 1;
  for (int i = 0 ; i < dim ; i++) {
    ia[++countCons] = countRows;
    ja[  countCons] = epsilonIndex;
    ar[  countCons] = -1.0;
    epsilonIndex += dim - i;
  }
  return;
}





//////////////////////////////////////////////////////////
//IMPORT THE PROBLEM TO THIRD-PARTY SOFTWARE


void LPClass::Import()
{
  cout << "  Import constraints into LP software" << endl;
  switch(solverInt) {
#ifdef GLPK_OPTIMIZE
  case SOLVER_GLPK :
    Import_GLPK();
    break;
#endif
#ifdef GUROBI_OPTIMIZE
  case SOLVER_GUROBI :
    Import_Gurobi();
    break;
#endif
#ifdef CPLEX_OPTIMIZE
  case SOLVER_CPLEX :
    Import_CPLEX();
    break;
#endif
  default :
    cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
  }

  return;
}

#ifdef GLPK_OPTIMIZE
void LPClass::Import_GLPK()
{
// create problem and read values in
  cout << "  Create new GLPK Object" << endl;
  lp = glp_create_prob();
  glp_set_prob_name(lp,"SLP");
  glp_set_obj_dir(lp,GLP_MIN);

  // specify control parameters: IMPORTANT!!!
  glp_init_smcp(&solverParams);
  solverParams.presolve = GLPK_PresolveVar;
  solverParams.tol_bnd = feasibleTol;
  solverParams.tol_dj = feasibleTol;
  solverParams.msg_lev = GLP_MSG_ERR; //Only print error and warning messages to the terminal

  glp_get_bfcp(lp,&otherParams);
  otherParams.type = GLPK_BasisFactType;
  glp_set_bfcp(lp, &otherParams);


  // first do the objective function and structural VARIABLES (i.e., position displacement and epsilons)
  glp_add_cols(lp,numVar); //if collective jamming, then epsilonNum=1

  //Deformable box variables:
  if (strictJam==0) {
    glp_set_obj_coef(lp,1,1.0);
    glp_set_col_bnds(lp,1,GLP_DB,-1.0*compMax,0.0); //Nowhere to expand in collective jamming!
  }
  else if (strictJam==1) {
    epsilonColTrack = 1;
    for (int i=0; i<dim; i++) {
      for (int l=i; l<dim; l++) {
	if (l==i) {
	  glp_set_obj_coef(lp,epsilonColTrack,1.0);
	  glp_set_col_bnds(lp,epsilonColTrack,GLP_DB,-1.0*compMax,compMax);
	}
	else {
	  glp_set_col_bnds(lp,epsilonColTrack,GLP_DB,-1.0*shearMax,shearMax);
	}
	epsilonColTrack = epsilonColTrack +1;
      }
    }
  }

  //Sphere displacement variables
  for (int i=epsilonNum +1; i<=numVar; i++) {
    glp_set_col_bnds(lp,i,GLP_DB,-1.0*transMax,1.0*transMax);
  }

  // now do the constraints lower bounds
  glp_add_rows(lp,numConstr);
  for (int i=1; i<=numConstr; i++) {
    switch(ineq[i]) {
    case INEQ_LESS_THAN : //Uppder bound
      glp_set_row_bnds(lp,i,GLP_UP,0.0,bounds[i]);
      break;
    case INEQ_GREATER_THAN : //Lower bound
      glp_set_row_bnds(lp,i,GLP_LO,bounds[i],0.0);
      break;
    case INEQ_EQUAL_TO :
      glp_set_row_bnds(lp,i,GLP_FX,bounds[i],0.0);
      break;
    }
  }

  return;
}
#endif



#ifdef GUROBI_OPTIMIZE
void LPClass::Import_Gurobi()
//Steps:
//1) Initialize the environment and run parameters
//2) Allocate variables and constraints
//3) Add strain variables
//4) Add delta (movement) variables
//5) Add constraints

{
  //Part 1: Initialize the environment/set parameters
  try {
    SetupEnvironment_Gurobi();
  
    //Now intialize the model off of that environment:
    cout<<"  Initialize Gurobi model..."<<flush;
    gModel = new GRBModel(*gEnv);

    //Part 2: Allocate variables (gVar) and constraints (gConstr)
    cout<<"Allocate..."<<flush;
    gVar    = new GRBVar   [numVar];
    gConstr = new GRBConstr[numConstr];
    gExpr   = new GRBLinExpr[numConstr];

    //Part 3: Add strain variables
    cout<<"strain vars..."<<flush;
    epsilonColTrack = 0;  //Start at zero because this is an array location (name is adjusted to be "+1")
    if (strictJam==0) {
      AddEpsilon_Gurobi(0,0,epsilonColTrack);
      epsilonColTrack++;
    }
    else if (strictJam==1) {
      for (int i=0; i<dim; i++) {
	for (int l=i; l<dim; l++) {
	  AddEpsilon_Gurobi(i,l,epsilonColTrack);
	  epsilonColTrack++;
	}
      }
    }

    //Part 4: add delta (movement) variables
    cout<<"displacement vars..."<<flush;
    int deltaIndex = 1;  //The ACTUAL NUMBER (for the name)!  (STARTS AT ONE)
    int varIndex = epsilonColTrack;
    for (int i=epsilonNum +1; i<=numVar; i++) {
      AddDelta_Gurobi(deltaIndex,varIndex);
      deltaIndex++;
      varIndex++;
    }
    //cout << "...done" << endl;

    //cout<<"set as minimization problem..."<<flush;
    //gModel->set(GRB_IntAttr_ModelSense,1); //Set the problem to be a minimization problem

    //Update the model so that the variables are loaded in:
    gModel->update();

    //Part 5: Add the constraint equations:
    cout<<"constraints..."<<flush;
    AddConstrs_Gurobi();
    gModel->update();
    
    cout<<"done."<<endl;
  }
  catch (GRBException e) {
    cout << "    Error code   = " << e.getErrorCode() << endl;
    cout << "    Error Message: "     << e.getMessage()   << endl;
  } catch (...) {
    cout << "  Unhandled error while initializing Gurobi " << endl;
  }

  //cout<<"  finished import into Gurobi"<<endl;

  return;
}

void LPClass::SetupEnvironment_Gurobi()
{
  if (gEnv) //Already set up (only needs to be done once for TJ
    return;

  cout<<"Initialize Gurobi Environment."<<endl;

  gEnv = new GRBEnv;
  
  //Set feasibility limits:
  double minTol = 1.0e-9; //The limits on the FeasibilityTol and OptimalityTol parameters for Gurobi (Simplex)
  double maxTol = 1.0e-2;
  if (feasibleTol >= minTol && feasibleTol <= maxTol) {//Alowed by Gurobi:
    grbExtraScale = 1.0; //Import constraints as-is
    gEnv->set(GRB_DoubleParam_FeasibilityTol,feasibleTol);
    gEnv->set(GRB_DoubleParam_OptimalityTol ,feasibleTol);
  }
  else if (feasibleTol < minTol) {//Lower than what is allowed by Gurobi!
    grbExtraScale = minTol / feasibleTol;
    gEnv->set(GRB_DoubleParam_FeasibilityTol,minTol);
    gEnv->set(GRB_DoubleParam_OptimalityTol ,minTol);
    cout << "  Gurobi: Extra-tight Feasibility tolerances--grbExtraScale = " << grbExtraScale << endl;
  }
  else if (feasibleTol > maxTol) {
    cout << "  Gurobi: Feasibility toleranes must be below 0.01" << endl;
    gEnv->set(GRB_DoubleParam_FeasibilityTol,maxTol);
    gEnv->set(GRB_DoubleParam_OptimalityTol ,maxTol);
  }
  gEnv->set(GRB_DoubleParam_BarConvTol,feasibleTol); //Barrier convergence doesn't care :)
    
  //Choose which solver will be used (Default is "Auto"
  if (strcmp(GRB_Method.c_str(),"Auto") == 0) {
    cout << "  Gurobi: Use Auto Solver\n";
    gEnv->set(GRB_IntParam_Method,-1);
  }
  else if (strcmp(GRB_Method.c_str(),"PrimalSimplex") == 0) {
    cout << "  Gurobi: Use Primal Simplex\n";
    gEnv->set(GRB_IntParam_Method,0);
  }
  else if (strcmp(GRB_Method.c_str(),"DualSimplex") == 0) {
        cout << "  Gurobi: Use Dual Simplex\n";
    gEnv->set(GRB_IntParam_Method,1);
  }
  else if (strcmp(GRB_Method.c_str(),"Barrier") == 0) {
    cout << "  Gurobi: Use Barrier Solver\n";
    gEnv->set(GRB_IntParam_Method,2);
  }
  else if (strcmp(GRB_Method.c_str(),"Concurrent") == 0) {
    cout << "  Gurobi: Use Concurrent Solver\n";
    gEnv->set(GRB_IntParam_Method,3); //Concurrent (non-deterministic!)
  }
  else if (strcmp(GRB_Method.c_str(),"ConcurrentDeterm") == 0) {
    cout << "  Gurobi: Use Concurrent Deterministic Solver\n";
    gEnv->set(GRB_IntParam_Method,3); //Concurrent (deterministic)
  }

  //BarHomogeneous off:
  gEnv->set(GRB_IntParam_BarHomogeneous,0);

  //Disable crossover:
  gEnv->set(GRB_IntParam_Crossover,0);

  //Set printing level:
  gEnv->set(GRB_IntParam_OutputFlag,0); //Disable output

  //Limit the number of threads that Gurobi uses:
  gEnv->set(GRB_IntParam_Threads,numThreads);

  //Presolve level:
  gEnv->set(GRB_IntParam_Presolve,GRB_Presolve);   //(-1,0,1,2) = (Auto (Default) , none , standard , aggressive)

  return;
}


void LPClass::AddEpsilon_Gurobi(int i,
				int l,
				int varIndex)
{
  //Get the name for this new variable:
  stringstream ss;
  ss << i+1 << l+1; //Start at x1...
  string varName = string("e") + ss.str();

  //cout << "  Adding variable " << varName << " to the model" << endl;

  //Get the right bounds and objective coefficient:
  double objCoef   = 0.0;
  double lowBound  = 0.0;
  double highBound = 0.0;
  if (strictJam==0) {
    objCoef = grbExtraScale*dim;
    lowBound = -1.0*compMax;
    highBound = 0.0; //No expansion allowed in Collective Jamming
  }
  else if (strictJam==1) {
    if (i == l) {//Bulk strain (matrix trace terms)
      objCoef = grbExtraScale; //1.0 when LP is not pre-scaled
      lowBound = -1.0*compMax;
      highBound = compMax;
    }
    else {//Shear strain
      objCoef = 0.0;
      lowBound  = -1.0*shearMax;
      highBound =      shearMax;
    }
  }

  //C++ method:
  try {
    gVar[varIndex] = gModel->addVar(lowBound, //Lower bound
				    highBound,  //Upper bound
				    objCoef,  //Coefficient in objective fcn
				    GRB_CONTINUOUS,//Type of variable (real)
				    varName.c_str()); //Name of the variable (first variable is "x1", second is "x2," etc.
  }
  catch(GRBException e) {
    cout << "    Error code   = " << e.getErrorCode() << endl;
    cout << "    Error Message: "     << e.getMessage()   << endl;
  } catch (...) {
    cout << "  Unhandled error while adding variable " << varName << endl;
  }

  return;
}


void LPClass::AddDelta_Gurobi(int deltaIndex,
			      int varIndex)
{
  //Get the name for this new variable:
  stringstream ss;
  ss << deltaIndex;
  string varName = string("d") + ss.str();

  //cout << "  Adding variable " << varName << " to the model" << endl;

  //Get the right bounds and objective coefficient:
  double objCoef   = 0.0;
  double lowBound  = -1.0*transMax;
  double highBound = transMax;


  //C++ method:
  try {
    gVar[varIndex] = gModel->addVar(lowBound, //Lower bound
				    highBound,  //Upper bound
				    objCoef,  //Coefficient in objective fcn
				    GRB_CONTINUOUS,//Type of variable (real)
				    varName.c_str()); //Name of the variable (first variable is "x1", second is "x2," etc.
  }
  catch(GRBException e) {
    cout << "    Error code   = " << e.getErrorCode() << endl;
    cout << "    Error Message: "     << e.getMessage()   << endl;
  } catch (...) {
    cout << "  Unhandled error while adding variable " << varName << endl;
  }

  return;
}


void LPClass::AddConstrs_Gurobi()
{
  //cout << "  Gurobi: Add constraints..." << endl;
  //Allocate row indices array:
  int numTerms = epsilonNum + 2*dim; //The number of variables associated with any given nonoverlap constraint
                                     //i.e. the strain terms, plus the movements for both particles

  //Loop through the constraints:
  int offset = 0;
  int constrIndex = 0;
  //The strain trace constraint (strict jamming only)
  if (strictJam==1) {
    offset = AddConstr_Gurobi(constrIndex,dim,offset); 
    constrIndex++;
  }

  //The interparticle contraints
  while (constrIndex < numConstr) {
    //cout << "    Constraint " << constrIndex+1 << endl;
    offset = AddConstr_Gurobi(constrIndex,numTerms,offset);
    constrIndex++;
  }//End of constraint loop
  //cout << "done" << endl;

  return;
}


double LPClass::AddConstr_Gurobi(int constrIndex,
				 int numTerms,
				 int offset)
{
  //Get the name for this new constraint:
  stringstream ss;
  ss << constrIndex+1; //Start at C1...
  string constrName = string("C") + ss.str();
  //cout << "  Adding constraint " << constrName << endl;

  //Initialize the constraint expression:
  //GRBLinExpr expr;

  //Add the terms to the expression:
  //int offset = constrIndex * numTerms; //Where to start reading from ja and ar
  //cout << "  Building..." << endl;
  //cout << "    ia,ja,ar up to " << numTerms+offset << endl;
  for (int iTerm = 1 ; iTerm <= numTerms ; iTerm++) {//ia, ja, ar start at 1, not 0.
    int varIndex = ja[iTerm+offset]-1; //Which variable we're dealing with (MUST MOVE BACK 1!)
    if (varIndex >= (numVar)) {
      cerr << "Tried to call varIndex = " << varIndex << endl;
    }
    double coef  = ar[iTerm+offset];
    //cout << "  (row , entry , varIndex , coef) = (" << ia[iTerm+offset]-1 << " , " << iTerm+offset << " , " << varIndex << " , " << coef << ")" << endl;
    gExpr[constrIndex] += grbExtraScale * coef * gVar[varIndex]; //Wow, yeah, this is weird to be doing -__-
  }

  //figure out what comparator to use:
  char grbSign;
  if (ineq[constrIndex+1] == INEQ_GREATER_THAN) {
    grbSign = GRB_GREATER_EQUAL;
  }
  else if (ineq[constrIndex+1] == INEQ_EQUAL_TO) {
    grbSign = GRB_EQUAL;
  }
  else if (ineq[constrIndex+1] == INEQ_LESS_THAN) {
    grbSign = GRB_LESS_EQUAL;
  }
  else {
    grbSign = GRB_GREATER_EQUAL; //Default, but should never happen!
    cerr << "Error: Unspecified comparator on constraint " << constrIndex+1 << endl;
  }


  /*
  cout.precision(2);
  cout << "  Constraint " << constrName << ": " << expr[constrIndex] << endl;
  cout << grbSign << " " << bounds[constrIndex];
  cout.precision(COUT_PRECISION);
  */  

  //Add the constraint to the model:
  //cout << "  Adding..." << endl;

  try {
    gConstr[constrIndex] = gModel->addConstr(gExpr[constrIndex],                    //Left-hand side
					     grbSign,                               //Inequality symbol
					     grbExtraScale * bounds[constrIndex+1], //Right-hand side...ADD ONE FOR STUPID GLPK CONVENTION ARTIFACT!!!
					     constrName);                           //Name of the constraint (C1,C2,C3,etc...)
  }
  catch(GRBException e) {
    cout << "    Error code   = " << e.getErrorCode() << endl;
    cout << "    Error Message: " << e.getMessage()   << endl;
  } catch (...) {
    cout << "  Unhandled error while adding constraint " << constrName << endl;
  }

  //cout << "  Done." << endl;
  
  return(offset+numTerms);//So that the next constraint knows where to start
}
#endif //GUROBI_OPTIMIZE



#ifdef CPLEX_OPTIMIZE
void LPClass::Import_CPLEX()
{
  cout<<"Import_CPLEX()\n";
  cout<<" Create mapping..."<<flush;
  //Create the mapping from the "real" variables to the ones used by CPLEX:
  //Wipe everything clean:
  cplex_numVar=0;
  for (int i=0; i<numVar; i++) {
    cplex_varUsed[i]    = false;
    cplex_sphereToLP[i] = -1;
    cplex_lpToSphere[i] = -1;
  }


  //Find out which are used:
  for (int i=0; i<numLHS; i++) {
    const int j = ja[i+1]-1;
    cplex_varUsed[j] = true;
  }

  //Create mapping:
  for (int i=0; i<numVar; i++) {
    if (cplex_varUsed[i]) {
      cplex_sphereToLP[i] = cplex_numVar;
      cplex_lpToSphere[cplex_numVar++] = i;
    }
  }
  cout<<"done."<<endl;

  try {
    cout<<"  CPLEX Initialize."<<endl;
    //Initialize environment:
    if (!cplex_env) {
      cout<<"    Initialize environment."<<endl;
      cplex_env = new IloEnv;
    }

    cplex_model = new IloModel(*cplex_env);
    cplex_var = new IloNumVarArray(*cplex_env);
    cplex_con = new IloRangeArray (*cplex_env);

    cout<<"CPLEX Populate."<<endl;
    //cplex_obj = new IloObjective;  
    cplex_obj = new IloObjective(*cplex_env);
    cplex_obj->setSense(IloObjective::Sense::Minimize);

    //Add constraints:

    cout<<" Constraints."<<endl;
    //Each call to "IloRangeArray::add()" puts another constraint equation into the model:
    for (int i=0; i<numConstr; i++) {
      switch(ineq[i+1]) {
      case INEQ_LESS_THAN :
	cplex_con->add(IloRange(*cplex_env,-IloInfinity,bounds[i+1]));
	break;
      case INEQ_GREATER_THAN :
	cplex_con->add(IloRange(*cplex_env,bounds[i+1],IloInfinity));
	break;
      case INEQ_EQUAL_TO :
	cplex_con->add(IloRange(*cplex_env,bounds[i+1],bounds[i+1]));
	break;
      }
      stringstream ss;
      if (constrSphere1[i+1]==0)
	ss<<"_Trace";
      else
	ss<<"_"<<constrSphere1[i+1]<<"_"<<constrSphere2[i+1];

      const string cName="c"+ss.str();
      (*cplex_con)[i].setName(cName.c_str());
    }

    //Add variables:

    cout<<" Variables."<<endl;
    //Each call to "x.add" puts another entry in the array...
    int varIdx=0;
    for (int i=0; i<cplex_numVar; i++) {
      const int j=cplex_lpToSphere[i];
      //Figure out its name and bounds!
      string varName   = "NONAME";
      double varBounds = 0.0;
      double objCoef   = 0.0;
      //Figure out if this is a normal or shear strain...or a displacement.
      if (j<epsilonNum) {//strain:
	if (!strictJam) {
	  varName = "e";
	  varBounds=compMax;
	  objCoef = 1.0;
	}
	else {
	  int thisRow=1; //Row of the strain matrix.
	  int k=j;
	  while (k>dim-thisRow)
	    k -= dim+1-thisRow++;
	  const int thisCol = thisRow+k;
	  stringstream ss; ss<<thisRow<<thisCol;
	  varName = "e"+ss.str();
	  if (thisRow==thisCol) {
	    varBounds = compMax;
	    objCoef   = 1.0;
	  }
	  else
	    varBounds = shearMax;
	}
      }
      else {//Displacement
	const int sphereIdx = ((j-epsilonNum) / dim) + 1;
	const int sphereDim = ((j-epsilonNum) % dim) + 1;
	stringstream ss; ss<<sphereIdx<<"_"<<sphereDim;
	varName = "x"+ss.str();
	varBounds = transMax;
      }
      
      //Add this variable!
      cplex_var->add(IloNumVar(*cplex_env,-varBounds,varBounds));
      if (objCoef != 0.0)
	cplex_obj->setLinearCoef((*cplex_var)[varIdx], 1.0);
      (*cplex_var)[varIdx++].setName(varName.c_str());
    }

    cout<<" Populate LHS."<<endl;
    //Populate the LHS:
    for (int k=0; k<numLHS; k++) {
      const int    i   = ia[k+1]-1; //constraint row (start at zero)
      const int    j   = cplex_sphereToLP[ja[k+1]-1]; //CPLEX variable index
      const double val = ar[k+1];
      //cout<<" "<<k+1<<": "<<"A("<<i<<","<<j<<") = "<<val<<endl;
      (*cplex_con)[i].setLinearCoef((*cplex_var)[j],val);
    }

    cout<<" Add."<<endl;
    cplex_model->add(*cplex_obj);
    cplex_model->add(*cplex_con);

    //Set up solve parameters:

    cout<<" Parameters."<<endl;
    cplex = new IloCplex(*cplex_env);
    cplex->extract(*cplex_model);
    //Set things up like I want:

    //Parallel?
    //cplex->setParam(IloCplex::Param::Parallel,1); //This is Deterministic vs Opportunistic; Barrier is strictly Deterministic.
    cout<<"  numThreads"<<endl;
    cplex->setParam(IloCplex::Param::Threads,numThreads);

    //Barrier Algorithm
    //cplex->setParam(IloCplex::Param::Algorithm,IloCplex::Barrier);
    cout<<"  Barrier"<<endl;
    cplex->setParam(IloCplex::Param::RootAlgorithm,IloCplex::Barrier);
    //Starting point (p.32 of Parameters manual)
    cplex->setParam(IloCplex::Param::Barrier::StartAlg,1);
    //No crossover
    cout<<"  No crossover"<<endl;
    cplex->setParam(IloCplex::Param::Barrier::Crossover,-1); //-1;no,auto,simplex,dual

    //Barrier Center Corrections
    //cplex->setParam(IloCplex::Param::Barrier::Limits::Corrections,0); //Default=-1 (automatic: let CPLEX choose); set higher to improve numerics
    //Covergence tolerance:
    cout<<"  Convergence tolerance"<<endl;
    static const double CPLEX_BARCONVTOL_MIN = 1.0e-12;
    if (feasibleTol < CPLEX_BARCONVTOL_MIN) {
      feasibleTol = CPLEX_BARCONVTOL_MIN;
      cerr<<" feasibleTol was too small for CPLEX; bumped up to "<<CPLEX_BARCONVTOL_MIN<<endl;
    }
    cplex->setParam(IloCplex::Param::Barrier::ConvergeTol,feasibleTol);
    //Starting Algorithm?  IloCplex::Param::Barrier::StartAlg
    //No printout:
    cout<<"  Run quiet"<<endl;
    cplex->setParam(IloCplex::Param::Barrier::Display,0);

    //cout<<"Export."<<endl;
    //cplex->exportModel("CPLEX_Model.lp");
  }
  catch (IloException& e) {
    cerr << "Concert exception caught: " << e << endl;
  }
  catch (...) {
    cerr << "Unknown exception caught" << endl;
  }
}
#endif


//////////////////////////////////////////////////////
//SOLVE THE LP


void LPClass::Solve()
{
  cout << "  Solve the LP" << endl;

  switch(solverInt) {
#ifdef GLPK_OPTIMIZE
  case SOLVER_GLPK :
    Solve_GLPK();
    break;
#endif
#ifdef GUROBI_OPTIMIZE
  case SOLVER_GUROBI :
    Solve_Gurobi();
    break;
#endif
#ifdef CPLEX_OPTIMIZE
  case SOLVER_CPLEX :
    Solve_CPLEX();
    break;
#endif
  default :
    cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
  }

  return;
}

#ifdef GLPK_OPTIMIZE
void LPClass::Solve_GLPK()
{
  glp_load_matrix(lp,numLHS,ia,ja,ar);

  // in case the basis matrix was singular on the last run
  if (warmUpParam) {
    //warmUpReturn = lpx_warm_up(lp);
    if (warmUpReturn == 0) {
      cout << "warm up successfully fixed the basis matrix\n";
    }
    else {
      cout << "warm up indicated that the basis matrix is numerically singular within the precision specified\n";
    }
  }

  solverStatus = glp_simplex(lp,&solverParams);

  if (solverStatus > 0) {
    cout << "solver encountered problems, running warm up to attempt to resolve\n";
    warmUpParam = true;
  }
  else {
    warmUpParam = false;
  }

  return;
}
#endif

#ifdef GUROBI_OPTIMIZE
void LPClass::Solve_Gurobi()
{
  cout << "  GUROBI OPTIMIZE" << endl;
  try {
    gModel->optimize();
    cout<<"Round 1 done."<<endl;
    
    //Figure out how the optimization went:
    int optimstatus = gModel->get(GRB_IntAttr_Status);

    if (optimstatus == GRB_INF_OR_UNBD) {
      gModel->getEnv().set(GRB_IntParam_Presolve, 0);
      gModel->optimize();
      optimstatus = gModel->get(GRB_IntAttr_Status);
    }

    if (GRB_Method == "Barrier")
      gIterCount = gModel->get(GRB_IntAttr_BarIterCount);
    else if (GRB_Method == "PrimalSimplex" || GRB_Method == "DualSimplex")
      gIterCount = (int) gModel->get(GRB_DoubleAttr_IterCount); //Not sure why it's a double...

    cout<<"  Gurobi optimization terminated after "<<gIterCount<<" iterations.\n";

    //Check optimizer status:
    if (optimstatus == GRB_OPTIMAL) {
      //Hooray!
    }
    else if (optimstatus == GRB_ITERATION_LIMIT) {
      cout << "Solver iteration limit reached!"<<endl;
    } 
    else if (optimstatus == GRB_INFEASIBLE) {
      cout << "Model is infeasible" << endl;

      // compute and write out IIS

      gModel->computeIIS();
      gModel->write("model.ilp");
    } 
    else if (optimstatus == GRB_UNBOUNDED) {
      cout << "Model is unbounded" << endl;
    }
    else if (optimstatus == GRB_ITERATION_LIMIT) {
      cout << "Max iterations exceeded" << endl;
    }
    else {
      cout << "Optimization was stopped with status = "
           << optimstatus << endl;
    }

    //If we wanted to check the LP sovler, here's where we do it!
    if (checkLPSolve) {
      cout<<"\n--LP solve check:\n";
      const int checkNumVar    = gModel->get(GRB_IntAttr_NumVars);
      const int checkNumConstr = gModel->get(GRB_IntAttr_NumConstrs);
      if (checkNumVar!=numVar)
	cerr<<"  Disagreement in number of variables: numVar="<<numVar<<", checkNumVar="<<checkNumVar<<endl;
      if (checkNumConstr!=numConstr)
	cerr<<"  Disagreement in number of constraints: numConstr="<<numConstr<<", checkNumConstr="<<checkNumConstr<<endl;
      cout<<"  Check variables.\n";
      bool badVar=false;
      for (int i=0; i<numVar; i++) {
	const double minVal=gVar[i].get(GRB_DoubleAttr_LB);
	const double maxVal=gVar[i].get(GRB_DoubleAttr_UB);
	const double solVal=gVar[i].get(GRB_DoubleAttr_X);
	if (solVal<minVal || solVal>maxVal) {
	  cerr<<"  Error on variable "<<gVar[i].get(GRB_StringAttr_VarName)<<": solution value "<<solVal<<" doesn't fall within bounds ["<<minVal<<","<<maxVal<<"]"<<endl;
	  badVar=true;
	}
      }
      if (!badVar) {
	cout<<"  No bad variables found.\n";
	for (int i=0; i<numVar; i++)
	  cout<<"    "<<gVar[i].get(GRB_StringAttr_VarName)<<" : ["<<gVar[i].get(GRB_DoubleAttr_LB)<<" , "<<gVar[i].get(GRB_DoubleAttr_X)<<" , "<<gVar[i].get(GRB_DoubleAttr_UB)<<"]\n";
      }
      cout<<"--LP solver check complete.\n"<<endl;
      checkLPSolve=false;
    }

  } catch(GRBException e) {
    cout << "Gurobi optimization exception; Error code = " << e.getErrorCode() << endl;
    cout << e.getMessage() << endl;
  } catch (...) {
    cout << "Error during optimization" << endl;
  }
  cout<<"DONE OPT"<<endl;

  return;
}
#endif



#ifdef CPLEX_OPTIMIZE
void LPClass::Solve_CPLEX()
{
  try {
    cout<<"CPLEX Solve..."<<flush;
    if (!cplex->solve() ) {
      cplex_env->error() << "Failed to optimize LP" << endl;
      throw(-1);
    }
    cout<<"done."<<endl;
  }
  catch (IloException& e) {
    cerr << "Concert exception caught: " << e << endl;
  }
  catch (...) {
    cerr << "Unknown exception caught" << endl;
  }
}
#endif


//////////////////////////////////////////////////////
//EXPORT THE LP'S RESULTS


void LPClass::Export(int lpIters)
//Update the packing with the results of the LP solve
{
  cout << "  Export LP results..." << flush;
  switch(solverInt) {
#ifdef GLPK_OPTIMIZE
  case SOLVER_GLPK :
    ExportStrain_GLPK();
    break;
#endif
#ifdef GUROBI_OPTIMIZE
  case SOLVER_GUROBI :
    ExportStrain_Gurobi();
    break;
#endif
#ifdef CPLEX_OPTIMIZE
  case SOLVER_CPLEX :
    ExportSolution_CPLEX();
    ExportStrain_CPLEX();
    break;
#endif
  default :
    cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
  }

  //Part 2: Apply the strain:
  ApplyStrain();

  //Part 3: Apply the movements:
  ExportMovements();

  //Part 4: Look at and store the interesting quantities to file
  ReviewResults();

  //Part 5: Export the LP solution to file (if wanted)
  if (printThisIter_LP) {
    switch(solverInt) {
#ifdef GLPK_OPTIMIZE
    case SOLVER_GLPK :
      cerr<<"LP export not supported for GLPK\n";
      break;
#endif
#ifdef GUROBI_OPTIMIZE
    case SOLVER_GUROBI :
      ExportLP_Gurobi();
      break;
#endif
#ifdef CPLEX_OPTIMIZE
    case SOLVER_CPLEX :
      ExportLP_CPLEX();
      break;
#endif
    default :
      cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
    }
  }

  cout<<"done."<<endl;

  return;
}

#ifdef GLPK_OPTIMIZE
void LPClass::ExportStrain_GLPK()
{
  // first the lattice vecs; start by creating the matrix (I + epsilon), which is updateLambdas
  if (strictJam==0) {
    epsilonColTrack=1;
    double dVal = glp_get_col_prim(lp,epsilonColTrack);
    epsilonColTrack++;
    gsl_matrix_set(updateLambdas,0,0,1.0 + dVal); //Only need to store a scalar
  }
  else if (strictJam==1) {
    epsilonColTrack = 1;
    for (int i=0; i<dim; i++) {
      for (int d=i; d<dim; d++) {
	double dVal = glp_get_col_prim(lp,epsilonColTrack);
	//cout << "   e" << i << d << " = " << dVal << endl;
	if (i==d) {
	  gsl_matrix_set(updateLambdas,i,d,1.0 + dVal);
	}
	else {
	  gsl_matrix_set(updateLambdas,i,d,dVal);
	  gsl_matrix_set(updateLambdas,d,i,dVal);
	}
	epsilonColTrack++;
      }
    }
  }

  return;
}
#endif


#ifdef GUROBI_OPTIMIZE
void LPClass::ExportStrain_Gurobi()
{
  try {
    // first the lattice vecs; start by creating the matrix (I + epsilon), which is updateLambdas
    if (strictJam==0) {
      epsilonColTrack = 0;
      double dVal = gVar[epsilonColTrack].get(GRB_DoubleAttr_X);
      epsilonColTrack++;
      for (int d=0;d<dim;d++)
	gsl_matrix_set(updateLambdas,d,d,1.0 + dVal); //Only need to store a scalar, but the matrix helps later 
    }
    else if (strictJam==1) {
      epsilonColTrack = 0;
      for (int i=0; i<dim; i++) {
	for (int d=i; d<dim; d++) {
	  double dVal = gVar[epsilonColTrack].get(GRB_DoubleAttr_X);
	  //cout << "   e" << i << d << " = " << dVal << endl;
	  if (i==d) {
	    gsl_matrix_set(updateLambdas,i,d,1.0 + dVal);
	  }
	  else {
	    gsl_matrix_set(updateLambdas,i,d,dVal);
	    gsl_matrix_set(updateLambdas,d,i,dVal);
	  }
	  epsilonColTrack++;
	}
      }
    }
  } catch(GRBException e) {
    cout << "Gurobi optimization exception; Error code = " << e.getErrorCode() << endl;
    cout << e.getMessage() << endl;
  } catch (...) {
    cout << "Error during optimization" << endl;
  }

  return;
}
#endif



#ifdef CPLEX_OPTIMIZE
void LPClass::ExportSolution_CPLEX()
{
  cout<<" CPLEX: Get Solution..."<<flush;
  try {
    cout<<"  A"<<endl;
    IloNumArray vals(*cplex_env);
    cout<<"  B"<<endl;
    cplex->getValues(vals,*cplex_var);
    cout<<"  C"<<endl;
    for (int i=0; i<numVar; i++) {
      if (cplex_varUsed[i]) {
	const int j = cplex_sphereToLP[i];
	cplex_sol[i] = vals[j];

      }
      else
	cplex_sol[i] = 0.0; //Unused variable--don't do anything!
    }
  }
  catch (IloException& e) {
    cerr << "Concert exception caught: " << e << endl;
  }
  catch (...) {
    cerr << "Unknown exception caught" << endl;
  }
  cout<<"done."<<endl;
}

void LPClass::ExportStrain_CPLEX()
{
  try {
    // first the lattice vecs; start by creating the matrix (I + epsilon), which is updateLambdas
    if (strictJam==0) {
      epsilonColTrack = 0;
      const double dVal = cplex_sol[epsilonColTrack++];
      for (int d=0;d<dim;d++)
	gsl_matrix_set(updateLambdas,d,d,1.0 + dVal); //Only need to store a scalar, but the matrix helps later 
    }
    else if (strictJam==1) {
      epsilonColTrack = 0;
      for (int i=0; i<dim; i++) {
	for (int d=i; d<dim; d++) {
	  const double dVal = cplex_sol[epsilonColTrack++];
	  //cout << "   e" << i << d << " = " << dVal << endl;
	  if (i==d) {
	    gsl_matrix_set(updateLambdas,i,d,1.0 + dVal);
	  }
	  else {
	    gsl_matrix_set(updateLambdas,i,d,dVal);
	    gsl_matrix_set(updateLambdas,d,i,dVal);
	  }
	}
      }
    }
  }
  catch (IloException& e) {
    cerr << "Concert exception caught: " << e << endl;
  }
  catch (...) {
    cerr << "Unknown exception caught" << endl;
  }
}
#endif




void LPClass::ApplyStrain()
{
  // now multiply: lambdas = (I + epsilon)*lambdas
  if (strictJam==0) {
    gsl_matrix_memcpy(updateTemp,lambdas);
    gsl_matrix_scale(updateTemp,gsl_matrix_get(updateLambdas,0,0)); //SCalar operation!
  }
  else if (strictJam==1) {
    for (int l=0; l<dim; l++) {
      for (int i=0; i<dim; i++) {
	updateTempVal = 0.0;
	for (int d=0; d<dim; d++) {
	  updateTempVal += gsl_matrix_get(updateLambdas,l,d)*gsl_matrix_get(lambdas,d,i);
	}
	gsl_matrix_set(updateTemp,l,i,updateTempVal);   // now updateTemp is the new lambdas matrix, (I+epsilon)*lambdas
      }
    }
  }

  return;
}


void LPClass::ExportMovements()
//Also keeps track of which particle moved farthest (relative to the total packing displacement)
//if termCriterion is "maxDisp"
{

  gsl_matrix *globalTotDisp = gsl_matrix_alloc(dim,1); //The total movement of the entire packing (in global coords)
  gsl_matrix **globalDisp = new gsl_matrix*[N]; //The movements (in global coords) of each individual sphere
  for (unsigned int d = 0 ; d < (unsigned int) dim ; d++) {gsl_matrix_set(globalTotDisp,d,0,0.0);}
  for (int i = 0 ; i < N ; i++) {
    globalDisp[i] = gsl_matrix_alloc(dim,1);
  }

  // now update the coordinates
  greatestMaxMoveVal = 0.0;
  for (int i=0; i<N; i++) {//Loop through the spheres
    for (int d=0; d<dim; d++) {//Loop through dimensions
      const int idx = epsilonNum + dim*i + d;
      switch(solverInt) {
#ifdef GLPK_OPTIMIZE
      case SOLVER_GLPK :
	deltaLocalCoords[d] = glp_get_col_prim(lp,idx+1);
	break;
#endif
#ifdef GUROBI_OPTIMIZE
      case SOLVER_GUROBI :
	deltaLocalCoords[d] = gVar[idx].get(GRB_DoubleAttr_X);//Note: gVar starts from 0, not 1.
	//ExportLP_Gurobi();
	break;
#endif
#ifdef CPLEX_OPTIMIZE
      case SOLVER_CPLEX :
	deltaLocalCoords[d] = cplex_sol[idx];//Note: starts from 0, not 1.
	break;
#endif
      default :
	cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
      }
      localCoords[dim*i +d] += deltaLocalCoords[d];
      if (localCoords[dim*i +d] >= 1.0) {//Apply periodic boundary movement
	localCoords[dim*i +d] -= 1.0;
      }
      else if (localCoords[dim*i +d] < 0.0) {
	localCoords[dim*i +d] += 1.0;
      }
    }

    // now calc the maximum movement for this sphere - only if NNLs are used
    //Movement is equal to eps*lambda*(r+dr) + lambda*dr
    // r and dr are local coords
    if (useNNL || termCriterion == "maxDisp") {
      maxMoveVal = 0.0;
      for (int l=0; l<dim; l++) {
	oldLambdasNewLocals[l] = 0.0;
	for (int d=0; d<dim; d++) {
	  oldLambdasNewLocals[l] += gsl_matrix_get(lambdas,l,d)*localCoords[dim*i +d];
	}
      }
      for (int l=0; l<dim; l++) {
	maxMoveVals[l] = 0.0;
	for (int d=0; d<dim; d++) {
	  epsilonVal = l==d ? gsl_matrix_get(updateLambdas,l,d) - 1.0 : gsl_matrix_get(updateLambdas,l,d);
	  maxMoveVals[l] += epsilonVal*oldLambdasNewLocals[d];
	}
	//Compute lambda*dr:
	for (int d=0; d<dim; d++)
	  maxMoveVals[l] += gsl_matrix_get(lambdas,l,d)*deltaLocalCoords[d];
	//computation of maxMoveVals for dimension l of sphere i is now complete
	if (termCriterion == "maxDisp") {
	  gsl_matrix_set(globalDisp[i],l,0,maxMoveVals[l]);
	}
	maxMoveVal += maxMoveVals[l]*maxMoveVals[l];
      }
      if (maxMoveVal > greatestMaxMoveVal) {
	greatestMaxMoveVal = maxMoveVal;
      }
    }//NNL
  }//Sphere loop (i)

  //If the termination criterion is "maxDisp", do those calculations now:
  if (termCriterion == "maxDisp") {
    GetMaxDisp(globalTotDisp,globalDisp);
  }

  if (useNNL) {
    greatestMaxMoveVal = sqrt(greatestMaxMoveVal);       // the scaling is necessary to match NNLextraDist
    maxSingleMove += greatestMaxMoveVal;
    cout << "  greatestMaxMoveVal = " << greatestMaxMoveVal << endl;
    cout << "  maxSingleMove      = " << maxSingleMove << "\n";
  }

  // now update the lambdas matrix officially
  gsl_matrix_memcpy(lambdas,updateTemp);

  latVol = getVol();
  cout << "  lattice volume     = " << latVol << "\n";

  // now check for overlap
  if (lpIters == maxIters -1) {                 // if it's the last iteration, resize only so greatest overlap is at contact!
    ifResize = resizeIfOverlap(false);
  }
  else {
    ifResize = resizeIfOverlap(true);
  }

  if (ifResize) {
    //cout << "overlap detected, resize necessary\n";
    latVol = getVol();
    cout << "  new lattice volume is " << latVol << "\n";
  }

  //Deallocate:
  gsl_matrix_free(globalTotDisp);
  for (int i = 0 ; i < N ; i++) {
    gsl_matrix_free(globalDisp[i]);
  }
  delete [] globalDisp;

  return;
}


void LPClass::GetMaxDisp(gsl_matrix  *globalTotDisp,
			 gsl_matrix **globalDisp)
//For the "maxDisp" termination criterion
{
  maxDisp = 0.0; //Reset

  //First, get the global movement:
  for (int i = 0 ; i < N ; i++) {
    gsl_matrix_add(globalTotDisp,globalDisp[i]);
  }
  gsl_matrix_scale(globalTotDisp,1.0 / ((double) N));
  for (int i = 0 ; i < N ; i++) {
    gsl_matrix_sub(globalDisp[i],globalTotDisp); //Remove packing's motion
    //Find the resulting movement:
    double thisDisp = 0.0;
    for (unsigned int d = 0 ; d < (unsigned int) dim ; d++) {
      double tempVal = gsl_matrix_get(globalDisp[i],d,0);
      thisDisp += tempVal*tempVal;
    }
    if (thisDisp > maxDisp) {//Compare the displacements squared, since this is faster
      maxDisp = thisDisp;
    }
  }

  maxDisp = sqrt(maxDisp) / biggestRad; //Scale back to true displacement (L2-norm), non-dimensionalize in terms of biggest radius

  cout << "  maxDisp = " << maxDisp << endl;

  return;
}


void LPClass::ReviewResults()
//Check the values that are being output as the solution
//  Just in case anything interesting is going on...
{
  cout << "  Check optimization results" << endl;

  //Check the strain matrix:
  double trace = 0.0;
  for (int d = 0 ; d < dim ; d++) {
    trace += gsl_matrix_get(updateLambdas,d,d);
  }
  trace -= dim;
  cout << "    Tr(strain) = " << trace << endl;
  if (trace == 0) {
    cout << "    Strain trace constraint ACTIVE" << endl;
  }

  //Check individual strain elements:
  for (int i = 0 ; i < dim ; i++) {
    //Diagonals:
    if (gsl_matrix_get(updateLambdas,i,i) - 1.0 == compMax) {
      cout << "  strain ("<<i+1<<","<<i+1<<") hit compMax (limited expansion)" << endl;
    }
    if (gsl_matrix_get(updateLambdas,i,i) - 1.0 == -compMax) {
      cout << "  strain ("<<i+1<<","<<i+1<<") hit compMax (limited compression)" << endl;
    }
    if (strictJam == 1) {//Only if it matters...
      for (int j = i+1 ; j < dim ; j++) {//Off-diagonals
	if (fabs(gsl_matrix_get(updateLambdas,i,j)) == shearMax) {
	  cout << "  strain ("<<i+1<<","<<j+1<<") hit shearMax (limited shear)" << endl;
	}
      }
    }
  }

  //Check sphere translations:
  int numHitTransMax = 0;
  for (int i=0; i<N; i++) {//Loop through the spheres
    for (int d=0; d<dim; d++) {//Loop through dimensions
      double dVal=0.0;
      const int idx = epsilonNum+dim*i+d;
      switch(solverInt) {
#ifdef GLPK_OPTIMIZE
      case SOLVER_GLPK :
	dVal = glp_get_col_prim(lp,idx+1);
	break;
#endif
#ifdef GUROBI_OPTIMIZE
      case SOLVER_GUROBI :
	dVal = gVar[idx].get(GRB_DoubleAttr_X);//Note: gVar starts from 0, not 1.
	break;
#endif
#ifdef CPLEX_OPTIMIZE
      case SOLVER_CPLEX :
	dVal = cplex_sol[idx];
	break;
#endif
      default :
	cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
      }
      if (fabs(dVal) == transMax) {
	numHitTransMax++;
      }
    }
  }
  if (numHitTransMax > 0) {
    cout << "    "<<numHitTransMax<<" translations hit transMax" << endl;
  }

  UpdateLPFile(lpIters+1,
	       trace,
	       (double) numHitTransMax / (double) dim);
	       

  return;
}


#ifdef GUROBI_OPTIMIZE
void LPClass::ExportLP_Gurobi()
//For now, the LP export file has this format:
//
//numConstr
//(loop through the constrs)
//[sphere 1] [sphere 2] ["1" for active, "0" for not]
//
//
{
  cout<<"    Exporting LP\n";

  stringstream ss; ss<<lpIters+1;
  string filename = parentDirectory + outputFilename + "_" + ss.str() + "LP.dat";
  try {
    ofstream outFile(filename.c_str() , ios::out);
    outFile<<gModel->get(GRB_IntAttr_NumConstrs)<<"\n";
    if (outFile.is_open()) {
      int varCount=1; //To go through the variables in the ia,ja,ar arrays
      for (int i = 0 ; i < (gModel->get(GRB_IntAttr_NumConstrs)) ; i++) {//Loop through the constraints
	//Output the spheres involved, and whether the constraint is active
	if (gExpr[i].size() == (unsigned int)(dim)) {//Trace constraint
	  outFile<<"-1\t-1\t"<<gConstr[i].get(GRB_IntAttr_CBasis)<<"\n";
	}
	else if (gExpr[i].size() == (unsigned int)(epsilonNum + 2*dim)) {//A constraint between a pair of spheres
	  const int sphere1 = (ja[varCount+epsilonNum  ] - epsilonNum - 1) / dim;
	  const int sphere2 = (ja[varCount+epsilonNum+1] - epsilonNum - 1) / dim;
	  //cout<<"Pair: "<<sphere1<<" , "<<sphere2<<"\n";
	  //cout<<"Check: "<<gExpr[i]<<"\n";
	  outFile<<sphere1<<"\t"<<sphere2<<"\t"<<gConstr[i].get(GRB_IntAttr_CBasis)<<"\n";
	}
	else {
	  cout<<"Constraint "<<i<<" has "<<gExpr[i].size()<<" terms\n";
	}
	varCount += gExpr[i].size();
      }
      outFile.close(); //and close
    }
  }
  catch (...) {
    cerr << "    Error trying to write " << filename << endl;
  }

  cout << "    Wrote to " << filename << endl;

  return;
}
#endif



#ifdef CPLEX_OPTIMIZE
void LPClass::ExportLP_CPLEX()
//For now, the LP export file has this format:
//
//numConstr
//(loop through the constrs)
//[sphere 1] [sphere 2] ["1" for active, "0" for not]
//
//
{
  cout<<"    Exporting LP\n";

  stringstream ss; ss<<lpIters+1;
  string filename = parentDirectory + outputFilename + "_" + ss.str() + "LP.dat";
  try {
    ofstream outFile(filename.c_str() , ios::out);
    outFile<<gModel->get(GRB_IntAttr_NumConstrs)<<"\n";
    if (outFile.is_open()) {
      int varCount=1; //To go through the variables in the ia,ja,ar arrays
      for (int i = 0 ; i < (gModel->get(GRB_IntAttr_NumConstrs)) ; i++) {//Loop through the constraints
	//Output the spheres involved, and whether the constraint is active
	if (gExpr[i].size() == (unsigned int)(dim)) {//Trace constraint
	  outFile<<"-1\t-1\t"<<gConstr[i].get(GRB_IntAttr_CBasis)<<"\n";
	}
	else if (gExpr[i].size() == (unsigned int)(epsilonNum + 2*dim)) {//A constraint between a pair of spheres
	  const int sphere1 = (ja[varCount+epsilonNum  ] - epsilonNum - 1) / dim;
	  const int sphere2 = (ja[varCount+epsilonNum+1] - epsilonNum - 1) / dim;
	  //cout<<"Pair: "<<sphere1<<" , "<<sphere2<<"\n";
	  //cout<<"Check: "<<gExpr[i]<<"\n";
	  outFile<<sphere1<<"\t"<<sphere2<<"\t"<<gConstr[i].get(GRB_IntAttr_CBasis)<<"\n";
	}
	else {
	  cout<<"Constraint "<<i<<" has "<<gExpr[i].size()<<" terms\n";
	}
	varCount += gExpr[i].size();
      }
      outFile.close(); //and close
    }
  }
  catch (...) {
    cerr << "    Error trying to write " << filename << endl;
  }

  cout << "    Wrote to " << filename << endl;

  return;
}
#endif

  
void LPClass::UpdateLPFile(int    lpIters,
			   double strainTrace,
			   double freeSpheres)
//Save to a file all of the statistics
//  of each optimization iteration that
//  are interesting
{
  cout << "  Write optimization stats to file" << endl;
  //Open the file (to make or to append):
  string filename = parentDirectory + outputFilename + "_Stats.dat";
  try {
    ofstream outFile;
    bool haveFile = false;
    if (lpIters > 0) {
      try {
	haveFile = boost::filesystem::exists(filename);
      }
      catch (...) {}
    }
    if (haveFile) {
      outFile.open(filename.c_str() , ios::app);
    }
    else {//Create the file and add the header:
      cout << "    Create a new file" << endl;
      outFile.open(filename.c_str() , ios::out);
      if (!outFile.is_open()) {
	cerr << "    Failed to open " << filename << endl;
	throw;
      }
      outFile << "#Iteration";
      outFile << "\t#phi";
      outFile << "\t#Tr(strain)";
      outFile << "\t#FreeSpheres";
      outFile << "\t#Timer";
      outFile << "\t#SolverIterations";
      outFile << endl;
    }
    //Proceed to write this iteration's data:
    timer.End();
    outFile.precision(printPrecision);
    outFile         << lpIters;
    outFile << "\t" << getSphereVol() / getVol();
    outFile << "\t" << strainTrace;
    outFile << "\t" << freeSpheres;
    outFile << "\t" << timer.timePassed;
    outFile << "\t" << gIterCount;

    outFile << endl; //End the line
    outFile.close(); //and close
  }
  catch (...) {
    cerr << "    Error trying to write Optimization stats" << endl;
  }

  cout << "    Wrote to " << filename << endl;

  return;
}
  



//////////////////////////////////////////////////////
//CLEANUP FOR LPCLASS


void LPClass::Cleanup()
//Deallocate arrays, etc
{
  // free memory      
  switch(solverInt) {
#ifdef GLPK_OPTIMIZE
  case SOLVER_GLPK :
    cout << "  Deallocate GLPK Object" << endl;
    glp_delete_prob(lp);
    glp_free_env();
    break;
#endif
#ifdef GUROBI_OPTIMIZE
  case SOLVER_GUROBI :
    delete gModel;
    gModel = NULL;
    //delete gEnv;  //Happens once with destructor
    delete [] gVar;
    gVar = NULL;
    delete [] gConstr;
    gConstr = NULL;
    delete [] gExpr;
    gExpr = NULL;
    break;
#endif
#ifdef CPLEX_OPTIMIZE
  case SOLVER_CPLEX :
    cplex->clearModel();
    delete cplex;
    cplex = NULL;
    delete cplex_model;
    cplex_model = NULL;
    delete cplex_var;
    cplex_var = NULL;
    delete cplex_con;
    cplex_con = NULL;
    delete cplex_obj;
    cplex_obj = NULL;
    cplex_env->end();
    delete cplex_env;
    cplex_env = NULL;
    
    break;
#endif
  default :
    cerr << "WARNING: Solver " << solver << " is not programmed." << endl;
  }

  delete [] ia;
  delete [] ja;
  delete [] ar;
  delete [] ineq;
  delete [] bounds;
  delete [] constrSphere1;
  delete [] constrSphere2;

  return;
}
