//LPClass.h
//Structure of the Linear Programming class

#ifndef LPCLASSHEADER
#define LPCLASSHEADER

//========================================================
// Libraries necessary for LPClass:

#ifdef GLPK_OPTIMIZE
  #ifdef STEVE_MACHINE
    #include <glpk.h>  //On Steve's systems
  #endif
  //Libraries as used on della:
  #ifdef DELLA_MACHINE
    #include <glpk/glpk.h>
  #endif
  //Libraries on positron:
  #ifdef POSITRON_MACHINE
    #include <glpk/glpk.h>
  #endif
  #ifdef MOLECULE_MACHINE
    #include <glpk.h> //For use on della
  #endif
#endif

#ifdef GUROBI_OPTIMIZE
#include <gurobi_c++.h>
#endif

#ifdef CPLEX_OPTIMIZE
  #include <ilcplex/ilocplex.h>
#endif

//========================================================
// Structure of LPClass

class LPClass {
 public:
  LPClass();
  ~LPClass();
  void LPRoutine(int lpIters,
		 int maxSize);    //Calls the whole process of generating, importing, solving, exporting, and cleaning up

  bool BarIterLimit_flag;

 private:
  enum solverList{
    SOLVER_INVALID,
    SOLVER_GLPK,
    SOLVER_GUROBI,
    SOLVER_CPLEX,
    numSolvers
  };

  enum ineqSigns {
    INEQ_LESS_THAN,
    INEQ_GREATER_THAN,
    INEQ_EQUAL_TO
  };

  bool    haveSolver; //Makes sure that you choose a solver that you've compiled
  int     solverInt; //Translates the string "solver" into an int for usage in switch statements
  double *tempVec1;
  double *tempVec2;
  int    *ia;       //Row    index (i.e. which constraint)
  int    *ja;       //Column index (i.e. which variable)
  double *ar;
  int    *ineq;
  double *bounds;
  int    *constrSphere1; //Keep track of the spheres involved in a constraint (starts at 1; 0 = strain)
  int    *constrSphere2; //Keep track of the spheres involved in a constraint (starts at 1; 0 = strain)
  int numConstr;    //Number of constraints in this problem
  int numVar;       //Number of variables
  int numLHS;       //Number of LHS entries in the constraint matrix
  double coeffVal;
  double dist;
  int countCons;
  int countRows;
  int epsilonColTrack;
  int success;
  int epsilonNum;
  int ifResize;
  gsl_matrix *updateLambdas;
  gsl_matrix *updateTemp;
  double *maxMoveVals;
  double *oldLambdasNewLocals;
  double *deltaLocalCoords;
  double maxMoveVal;
  double greatestMaxMoveVal;
  double epsilonVal;
  double updateTempVal;
  double latVol;
  int solverStatus;
  bool warmUpParam;
  int warmUpReturn;

  //Solver variables:

  //GLPK variables:
#ifdef GLPK_OPTIMIZE
  glp_prob *lp;
  glp_smcp solverParams;
  glp_bfcp otherParams;
#endif

  //Gurobi variables:
#ifdef GUROBI_OPTIMIZE
  GRBEnv     *gEnv;          //The Gurobi environment
  GRBModel   *gModel;        //The LP model
  GRBVar     *gVar;          //The variables
  GRBConstr  *gConstr;       //The constraints
  GRBLinExpr *gExpr;         //The (linear) expressions for the constraints
#endif
  double      grbExtraScale; //To push the Feasibility tolerances beyond what Gurobi usually will do
  int         gIterCount;    //Number of iterations Gurobi did in the last solve

  //CPLEX Variables:
#ifdef CPLEX_OPTIMIZE
  bool           *cplex_varUsed;
  int            *cplex_sphereToLP; //index matching array
  int            *cplex_lpToSphere; //index matching array
  int             cplex_numVar;
  IloEnv         *cplex_env;
  IloModel       *cplex_model;
  IloObjective   *cplex_obj;
  IloNumVarArray *cplex_var;
  IloRangeArray  *cplex_con;
  IloCplex       *cplex;
  double         *cplex_sol;
#endif

  //Functions:

  //Initialize the variables to starting values:
  void Initialize();

  //Generating constraints:
  void Generate(int maxSize); //Generates the LP constraints and imports them into the solver of choice (maxSize is the maximum number of constraints)
  void Generate_NNL(int maxSize);    //If there's a near-neighbor list to use
  void Generate_NoNNL(int maxSize);  //No near-neighbor list.
  void ApplyBulkStrainConstraint();  //Prevents volume-increasing strains (to 1st order)

  //Importing the problem into a solver:
  void Import();
#ifdef GLPK_OPTIMIZE
  void Import_GLPK();
#endif
#ifdef GUROBI_OPTIMIZE
  void   Import_Gurobi();
  void   SetupEnvironment_Gurobi();
  void   AddEpsilon_Gurobi(int i,
			   int l,
			   int varIndex); //Functions for adding variables to gVar
  void   AddDelta_Gurobi(int deltaIndex,
			 int varIndex);
  void   AddConstrs_Gurobi();
  double AddConstr_Gurobi(int constrIndex,
			  int numTerms,
			  int offset);
#endif
#ifdef CPLEX_OPTIMIZE
  void   Import_CPLEX();
#endif
  //Solving using the LP software:
  void Solve();
#ifdef GLPK_OPTIMIZE
  void Solve_GLPK();
#endif
#ifdef GUROBI_OPTIMIZE
  void Solve_Gurobi();
#endif
#ifdef CPLEX_OPTIMIZE
  void Solve_CPLEX();
#endif

  //Exporting the solve's results:
  void Export(int lpIters);
#ifdef GLPK_OPTIMIZE
  void ExportStrain_GLPK();
#endif
#ifdef GUROBI_OPTIMIZE
  void ExportStrain_Gurobi();
#endif
#ifdef CPLEX_OPTIMIZE
  void ExportSolution_CPLEX();
  void ExportStrain_CPLEX();
#endif
  void ApplyStrain();
  void ExportMovements();
  void GetMaxDisp(gsl_matrix  *globalTotDisp,
		  gsl_matrix **globalDisp); //if the SLP termination criterion is maxDisp, this is called
  void ReviewResults(); //To see if any variables hit limits (especially if the non-positive trace constraint is being invoked!)
#ifdef GUROBI_OPTIMIZE
  void ExportLP_Gurobi(); //Export the Lp's solution to file
#endif
#ifdef CPLEX_OPTIMIZE
  void ExportLP_CPLEX();
#endif
  void UpdateLPFile(int    lpIters,
		    double strainTrace,
		    double freeSpheres);  //Write the interesting quantities to file

  //Cleanup: deallocation of arrays, etc.
  void Cleanup();

};

#endif
