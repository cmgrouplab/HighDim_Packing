//A header file with all of the global variables used in the program

#ifndef GLOBALVARIABLESHEADER

#include <string>

#include "main.h"

// fundamental constants
const double PI = 4.0*atan(1.0);
const double E = 2.71828182845904523536;

// random number generator setup
const gsl_rng_type * RNGtype;
gsl_rng *RNG;

// input file variables - these are the defaults in case input isn't read!
// See file "HopkinsTJ.standard.input" for details about all of these parameters
bool   readInitFile = false;
bool   readInitRadii = false;
bool   useNNL = false;
std::string inputParametersFilename;
std::string parentDirectory;
bool   have_initConfigName = false; //May be specified either at flags or in the input parameters file.
std::string initConfigName;
std::string initRadiiName;
std::string outputFilename;
bool autoSave = false; //Whether to save progress in a temporary folder periodically
std::string tempFolder;     //The name of the temporary folder where autosave information is saved
int    N = 0;                   //The number of spheres
int    dim = 0;                 //The dimension of the problem
bool   maxInitRad = false;      //If true, the radii of the spheres are maximized in the IC (so that the first contact is made)
double transMax = 0.05;      //The maximum translation of a sphere in a single LP step (lattice vectors?)
double compMax = 0.02;       //The maximum bulk (compressive) strain in a single step
double shearMax = 0.021;     //The maximum shear              strain in a single step
int    strictJam = 1;        //1 allows for full box deformations (as allowed by compMax and shearMax), but 0 resticts the compression to be shape-preserving (which will cause collective jamming instead of strict jamming)
bool   useStrictAfter=false; //Sets to "true" only if #strictAfter param is given
double strictAfter=0.0;      //Turns on shear DOFs after this packing fraction is exceeded (0=always strict; 1=always collective
double delta = 2.0;          //The influence sphere radius (?)

int    maxIters = 5000;      //The maximum number of times the LP solver may be invoked
std::string termCriterion;        //Either "maxDisp" or "latticeVol"
double phiTerm = 1.0;        //The maximum density allowed by the simulation (nice when we want to stop early)
double termTol = 1.0e-6;     //The termination criterion: if the density changes by less than this, then we are done (?)
                             //Alternatively, if the biggest sphere movement (relative to the center of gravity) was smaller than this, then we're done
double* phiHist=NULL;
int    termPhiHist=0;
double termPhiHistDecFrac=0.3;
int    termPhiHistDecNum=0;

double MCStartSweeps = 0.0;  //How many MC sweeps to do before the SLP algorithm
double MCMidSweeps = 0.0;    //How many MC sweeps to do after each LP iteration          
double mc_dispLimit;         //The displacement limit for a trial move in the MC routine
double maxDisp;              //The farthest (relative to the total packing displacement) that a sphere has moved in an iteration
bool   bidisperse=false;     //For easy bidisperse packings
double bidisperse_x=0.5;     //Number fraction of spheres that are small (between 0 and 1)
double bidisperse_a=1.0/1.4; //Size ratio (between 0 and 1)
bool   randLatVecs = false;  //When generating a packing, whether or not the lattice vectors should be random (otherwise, cube)
double maxLatLength = 1.0;   //The maximum length of a lattice vector (at initialization) (?)
double minLatLength = 0.25;  //The minimum length of a lattice vector (at initialization)
double minAngDeg = 30.0;     //The minimum angle between vectors when starting the lattice.
double manualMinVol = 0.20;  //
double radLatTol = 0.75;
int    topFail = 10000;
int    maxVolNum = 1000;
double inputPhi = 0.27;         //The intial (starting) density
int    overBoxes = 1;           //How many rings (of periodic image cells) to check beyond the actual cell (0 = use L/2 method)
int    maxBoxNum = 7;
bool   randOverlapMove = true;
double resizeSpace = 0.005;
double resizeTol = 1.0e-6;
double NNLextraDist = 0.50;
int    printEvery = 0;         //if >0, Write out the configuration to file after every [this many] iterations
bool   printThisIter_pkg;
bool   printThisIter_LP;
int    printPrecision = 16;    //Number of decimal places - outFile.precision(printPrecision);
bool   useTimer = 0;           //Whether to time the run (1) or not (0).  Units are microseconds
bool   scaleUnitRadius = 0;    //If yes, scale the packing so that the smalest sphere has radius = 1
double rescaleIC = 1.0;        //After you make/load an IC, multiply the size of the packing by this (to "rewind" packings)
int    printLPEvery = 0;       //if >0, Write out the LP's solution to file after every [this many] iterations

// Timer variables:
TimerClass timer; //See timer.h for structure
TimerClass saveTimer; //To save the data periodically

// running variables
gsl_matrix *lambdas;
gsl_matrix *inverseLambdas;
double *localCoords = 0;
double *globalCoords = 0;
double *radii = 0;
double *distTempL = 0;
double *distTempG = 0;
NeighborNode **neighborListDelta = 0;
NeighborNode **neighborListOverlap = 0;
int lpIters = 0; //The number of LP iterations that have gone by
double maxSingleMove = 0.0;
double biggestRad = 0.0;

//Solver variable:
std::string solver = "Gurobi";                 //"GLPK" or "Gurobi"
bool checkLPSolve=false;

//GLPK solver params
double feasibleTolMin = 1.0e-12;
double feasibleTolMax = 1.0e-6;
double feasibleTol    = feasibleTolMax;
double pivotTol = 0.1; //Default value used by GLPK, 0<pt<1...increase to improve numerical accuracy...
int GLPK_PresolveVar = 0;
int GLPK_BasisFactType = 1;

//Gurobi solver params
std::string GRB_Method = "Auto"; //Which solver to use
int    GRB_Presolve = 0;    //How much presolving to do (-1,0,1,2) = (auto,none,standard,aggresive)

//General IP params
int    numThreads = 1;   //Limit how many threads the solver can use at once

#define GLOBALVARIABLESHEADER
#endif
