//TimerClass.h: Structure of the TimerClass class

Class TimerClass {
 public:
  void Start();
  void End();
  void DisplayTime();
 private:
  struct timeval LPStartTime;
  struct timeval LPEndTime;
  int timeOfLP;
}
