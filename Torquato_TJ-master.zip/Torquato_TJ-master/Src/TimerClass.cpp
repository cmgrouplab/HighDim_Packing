//TimerClass.cpp
//Implementation of the TimerClass class


#include <time.h>
#include <iostream>

#include "TimerClass.h"

using namespace std;

void TimerClass::Start()
{
  //startTime = clock();
  startTime = time(NULL);
  return;
}

void TimerClass::End()
{
  //endTime = clock();
  endTime = time(NULL);
  //time = ((double) endTime - startTime) / CLOCKS_PER_SEC;
  timePassed = endTime - startTime;
  return;
}

void TimerClass::Display()
{
  cout << "Elapsed time = " << timePassed << endl;
  return;
}

//void TimerClass::PrintToFile
    
