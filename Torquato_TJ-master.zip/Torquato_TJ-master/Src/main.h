//main.h
//Structure of the program
//If you're looking for variables, go to GlobalVariables.h

#ifndef MAINHEADER

#include <string>
#include <gsl/gsl_matrix.h>
#include "macros.h"
#include "TimerClass.h"
#include "LPClass.h"

/////////////////
//Variables

// fundamental constants
extern const double PI;
extern const double E;

//NeighborNode class:
class NeighborNode {
 public:
  NeighborNode *next;
  int index;

  ~NeighborNode() {
    if (next != 0) {
      delete next;
    }
  }
};

// random number generator setup
extern const gsl_rng_type * RNGtype;
extern gsl_rng *RNG;

// input file variables - these are the defaults in case input isn't read!
// See file "HopkinsTJ.standard.input" for details about all of these parameters
extern bool   readInitFile;
extern bool   readInitRadii;
extern bool   useNNL;
extern std::string inputParametersFilename;
extern std::string parentDirectory;
extern bool   have_initConfigName;   //May be specified either at flags or in the input parameters file.
extern std::string initConfigName;
extern std::string initRadiiName;
extern std::string outputFilename;
extern bool   autoSave;              //Whether to save progress in a temporary folder periodically
extern std::string tempFolder;       //The name of the temporary folder where autosave information is saved
extern int    N;                     //The number of spheres
extern int    dim;                   //The dimension of the problem
extern bool   maxInitRad;            //If true, the radii of the spheres are maximized in the IC (so that the first contact is made)
extern double transMax;              //The maximum translation of a sphere in a single LP step (lattice vectors?)
extern double compMax;               //The maximum bulk (compressive) strain in a single step
extern double shearMax;              //The maximum shear              strain in a single step
extern int    strictJam;             //1 allows for full box deformations (as allowed by compMax and shearMax), but 0 resticts the compression to be shape-preserving (which will cause collective jamming instead of strict jamming)
extern bool   useStrictAfter;        //Sets to "true" only if #strictAfter param is given
extern double strictAfter;           //Turns on shear DOFs after this packing fraction is exceeded (0=always strict; 1=always collective
extern double delta;                 //The influence sphere radius (?)

//Termination parameters
extern int    maxIters;              //The maximum number of times the LP solver may be invoked
extern std::string termCriterion;    //Either "maxDisp" or "latticeVol"
extern double phiTerm;               //The maximum density allowed by the simulation (nice when we want to stop early)
extern double termTol;               //The termination criterion: if the density changes by less than this, then we are done (?)
                                     //Alternatively, if the biggest sphere movement (relative to the center of gravity) was smaller than this, then we're done
//Setting termPhiHist to a positive number turns on the termination criterion based off of the density history.
//Example: termPhiHist=10 and termPhiHistDecFrac = 0.5
//If, in the last 10 solves, the density dropped 5 times or more, then then signal that we should terminate.
extern double* phiHist;              //The array in which the history is stored.
extern int    termPhiHist;           //If >0, records history of phi and signals to terminate if the density keeps going downwards.
extern double termPhiHistDecFrac;    //Maximum fraction of allowable decreases
extern int    termPhiHistDecNum;     //Automatically calulates maximum number of decreases.

extern double MCStartSweeps;         //How many MC sweeps to do before the SLP algorithm
extern double MCMidSweeps;           //How many MC sweeps to do after each LP iteration          
extern double maxDisp;               //The farthest (relative to the total packing displacement) that a sphere has moved in an iteration
extern bool   bidisperse;            //For easy bidisperse packings
extern double bidisperse_x;          //Number fraction of spheres that are small (between 0 and 1)
extern double bidisperse_a;          //Size ratio (between 0 and 1)
extern bool   randLatVecs;           //When generating a packing, whether or not the lattice vectors should be random (otherwise, cube)
extern double maxLatLength;          //The maximum length of a lattice vector (at initialization) (?)
extern double minLatLength;          //The minimum length of a lattice vector (at initialization)
extern double minAngDeg;             //The minimum angle between vectors when starting the lattice.
extern double manualMinVol;          //
extern double radLatTol;
extern int    topFail;
extern int    maxVolNum;
extern double inputPhi;              //The intial (starting) density
extern int    overBoxes;             //How many rings (of periodic image cells) to check beyond the actual cell (0 = use L/2 method)
extern int    maxBoxNum;	     
extern bool   randOverlapMove;	     
extern double resizeSpace;	     
extern double resizeTol;
extern double NNLextraDist;
extern int    printEvery;            //if >0, Write out the configuration to file after every [this many] iterations
extern bool   printThisIter_pkg;     //Flag for printing configurations
extern bool   printThisIter_LP;      //Flag for printing LP solutions
extern int    printPrecision;        //Number of decimal places - outFile.precision(printPrecision);
extern bool   useTimer;              //Whether to time the run (1) or not (0).  Units are microseconds
extern bool   scaleUnitRadius;       //If yes, scale the packing so that the smalest sphere has radius = 1
extern double rescaleIC;             //After you make/load an IC, multiply the size of the packing by this (to "rewind" packings)
extern int    printLPEvery;          //if >0, Write out the LP's solution to file after every [this many] iterations

// Timer variables:
extern TimerClass timer;             //See timer.h for structure
extern TimerClass saveTimer;         //To save the data periodically

// running variables
extern gsl_matrix *lambdas;                //Lattice matrix (spanned by columns)
extern gsl_matrix *inverseLambdas;         //its inverse
extern double *localCoords;                //dim*N long, for all spheres
extern double *globalCoords;               //dim*N long
extern double *radii;                      //N long, radius of each sphere
extern double *distTempL;                  //a temporary displacement vector (local  coords)
extern double *distTempG;                  //a temporary displacement vector (global coords)
extern NeighborNode **neighborListDelta;   //NNL for the influence sphere
extern NeighborNode **neighborListOverlap; //NNL for looking ahead of that 
extern int lpIters;                        //The number of LP iterations that have gone by
extern double maxSingleMove;               //The running sum of the farthest sphere move in every LP iteration (since an NNL reset)
extern double biggestRad;                  //The biggest sphere's radius

//Solver variable:
extern std::string solver;                 //"GLPK" or "Gurobi"
extern bool checkLPSolve;                  //Check the output of the solver.

//Universal solver params
extern double feasibleTolMin; //Highest accuracy
extern double feasibleTolMax; //Lowest  accuracy
extern double feasibleTol;    //Current accuracy

//GLPK solver params
extern double pivotTol;        //Default value used by GLPK, 0<pt<1...increase to improve numerical accuracy...
extern int GLPK_PresolveVar;
extern int GLPK_BasisFactType;

//Gurobi solver params
extern std::string GRB_Method; //Which solver to use
extern int    GRB_Presolve;    //How much presolving to do (-1,0,1,2) = (auto,none,standard,aggresive)

//General IP solving parameters:
extern int    numThreads;   //Limit how many threads Gurobi can use at once





////////////////////////////////////////////////
// Functions





bool   ReadFlags(int argc,                               // Gets the name of the input file to be used
		 char **argv);                           // returns have_outputFilename
bool   readInput(bool have_outputFilename);            // Returns "true" if a packing has been successfully loaded
int    GetNFromPacking(std::string initConfigName);
bool   ReadPacking(std::string inFilename);            // Read in a packing from the location in inFilename; returns "true" if it was successful
void   RescalePacking();                               // Rescales a packing by multiplying all dimensions by "resizeIC"
void   MaximizeRadii();                                // Rescales a packing by maximizing the radii without generating an overlap
gsl_matrix *getInverse(gsl_matrix *matrixToInvert);    // inverts matrixToInvert
void   getRSAbox();                  		       // gets an RSA box and places the lattice vectors in matrix lambdas
double getAngle(int i,
		int j);     		               // specifies the angle between two lambdas matrix lattice vectors
double getVol();                   		       // specifies the volume of the lambdas matrix lattice vectors
void   setSphereRadii();             		       // sets sphere radii in relation to lambdas matrix lattice vectors
double getSphereVol();                                 //Gets the total volume of the spheres (for quick density calculations)
void   placeSpheres();               		       // this places the spheres of radii radii[] inside the lambdas unit cell
double getGlobalLength(double *inputVec);	       // gets the global length according to lambdas lattice vectors of inputVec
double getMinHeight();                                 // gets the min height w/i the unit cell of lambdas lattice vectors using SVD
int    calcNNLs();                                     // builds the two NNLs, one for inclusion sphere calc and one for overlap calc
void   DeleteOldNNL();                                 // Deallocation routine
int    resizeIfOverlap(bool randOver);                 // checks overlap and if overlap, resizes lattice by (resize to contact + resizeSpace)
int    solveLP(int maxSize);                           // solves the LP given the positions, radii, lattice and limits. Updates coords and lambdas
bool   CheckTermination(LPClass &LP,
			double lastLastVol,
			double latVol,
			double phi);                   // Find out if the selected termination criterion has been met
int    printPacking(std::string thisOutputFilename,
		    bool        addIterNum);           // prints the packing to the destination supplied in thisOutputFilename
void   LoadSaveData();                                 // If a saved packing was found, we want to retrieve where it left off, etc.
void   SaveProgress();                                 // Prints the packing to a temporary file in case execution is interrupted
void   ClearSaveData();                                //Deletes the TEMP directory and its contents (if they exist)
void   PrintTime(TimerClass timer);                    // Prins to a file ("Time.txt") how long it took to run the LP 

#define MAINHEADER
#endif



