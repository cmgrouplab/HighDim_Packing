/*
 * main.cpp
 *
 *  Created on: Nov 10, 2011
 *      Author: ahopkins
 */

//Execution:
// ./TJ
//    --Returns usage and ends (no longer an acceptable usage)
// ./TJ -I filename.input
//    --runs the program using filename.input to set the run parameters
// ./TJ -I filename.input -T TEMPDIR
//    --runs the program using filename.input to set the run parameters and saving/accessing temporary save data from "TEMPDIR"


#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <gsl/gsl_math.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_sort_vector.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_linalg.h>
#include <sys/time.h>
#include <time.h>
#include <math.h>
#include <limits.h>
#include <string.h>
#include <sstream>
#include <assert.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

//Libraries as used on Steve's machines:
#ifdef STEVE_MACHINE
#include <boost/filesystem.hpp> //Steve's systems
#endif
//Libraries as used on della:
#ifdef DELLA_MACHINE
#include <boost/filesystem/operations.hpp>
#endif
//Libraries on positron:
#ifdef POSITRON_MACHINE
#include <boost/filesystem/operations.hpp>
#endif
#ifdef MOLECULE_MACHINE
#include <boost/filesystem.hpp>
#endif

//Headers
#include "TimerClass.h"    //Header for timing-related operations
#include "global.h"        //Header with a bunch of global variables
#include "main.h"          //Header file for this program
#include "LPClass.h"       //Header for LP-related operations
#include "MCSweep.h"       //Monte Carlo sweeps

using namespace std;

int main (int    argc,
	  char **argv)
{
  //========================================
  // random number generator initialization

  {
    int randomData = open("/dev/random", O_RDONLY);
    unsigned long int seed=0;
    int result = read(randomData, &seed, (sizeof seed));
    assert(result>=0);

    gsl_rng_env_setup();
    RNGtype = gsl_rng_mt19937;
    RNG = gsl_rng_alloc(RNGtype);
    gsl_rng_set(RNG,seed);
    cout<<"RNG seed = "<<seed<<endl;
  }

  cout.precision(COUT_PRECISION);

  // variables
  int printSuccess = 0;
  int ifResize = 0;
  double latVol = 0.0;
  int totNeighbors = 0;    // this is the return if NNLs are used of calcNNLs
  double lastVol = 0.0;
  double lastLastVol = 0.0;

  bool have_outputFilename = ReadFlags(argc,argv);
  cout << "Input file is " << inputParametersFilename << endl;
  bool havePacking = readInput(have_outputFilename); 

  ////////////////////////////////////////////////////
  //Initialize the Packing
  ////////////////////////////////////////////////////

  // below is the RSA generator (box and spheres)
  if (!havePacking) {//If we don't have a packing yet, then make one!
    cout << "Generating a new packing..." << endl;
    if (randLatVecs) {// this is the case where random lattice vectors are desired
      getRSAbox();
    }
    else {// this is the case where a perfect cube is desired
      for (int i=0; i<dim; i++) {
	gsl_matrix_set(lambdas,i,i,1.0);
      }
    }

    latVol = getVol();
    cout << "Initial lattice volume is " << latVol << "\n";
    for (int i=0; i<dim; i++) {
      for (int j=0; j<dim; j++) {
	printf("lambdas[%i,%i] = %g\n",j,i,gsl_matrix_get(lambdas,j,i));
      }
    }

    setSphereRadii();           // this sets actual radii[] in relation to the lambdas matrix lattice vectors
    if (scaleUnitRadius) {latVol = getVol();} //In case the lattice was scaled

    placeSpheres();             // this completes the actual RSA placement process inside the lambdas unit cell
  }

  //If the "rescale" function is asked for, do it here:
  if (rescaleIC > 1.0) RescalePacking();

  //Find the total volume of the spheres:
  double sphereVol = getSphereVol();

  //Get the biggest lattice vector

  // rescale all pertinent variables, e.g., delta, etc., by biggestRad. Don't rescale tolerances!!!
  // also note that resizeSpace is not rescaled because resizeSpace is in units of the contact distance b/t two overlapping spheres
  cout << "biggestRad = " << biggestRad << "\n";
  delta = delta*biggestRad;
  NNLextraDist = NNLextraDist*biggestRad;
  const double transMaxL = transMax*biggestRad;
  compMax = compMax*biggestRad;
  shearMax = shearMax*biggestRad;
  cout << "delta = " << delta << "\n";
  cout << "NNLextraDist = " << NNLextraDist << "\n";
  cout << "transMax = " << transMax << "\n";
  cout << "compMax = " << compMax << "\n";
  cout << "shearMax = " << shearMax << "\n";

  //Initializing the NNL, if required
  if (useNNL) {
    // create the array that holds the neighborNode first addresses
    neighborListDelta = new NeighborNode *[N];
    neighborListOverlap = new NeighborNode *[N];
    for (int i=0; i<N; i++) {
      neighborListDelta[i] = 0;
      neighborListOverlap[i] = 0;
    }
    totNeighbors = calcNNLs();
    cout << "initial NNL maxSize = " << totNeighbors << "\n";
  }

  //Resizing the initial configuration (if needed)
  ifResize = resizeIfOverlap(false);
  if (ifResize) {
    latVol = getVol();
    cout << "Initial resize was required. New lattice volume is " << latVol << "\n";
  }

  //Initial Monte Carlo Sequence (equilibrating the IC)
  MC_Init();
  if (MCStartSweeps > 1.0) {
    for (int mcIndex = 0 ; mcIndex < (int) MCStartSweeps ; mcIndex++) {
      cout << mcIndex+1 << " / " << MCStartSweeps << "\n";
      double mc_maxDisp = MC_Sweep(N);
      //Re-calculate NNL if needed:
      maxSingleMove += mc_maxDisp;
      if (useNNL && (maxSingleMove > NNLextraDist/2.0)) {
	maxSingleMove = 0.0;
	cout << "Recalculating NNLs\n";
	totNeighbors = calcNNLs();
      }
    }
  }
  else if (MCStartSweeps > 0.0) {//Partial sweep
    int numTries = (int) (MCStartSweeps * N);
    MC_Sweep(numTries);
  }

  //If we wanted to maximize the initial density, rescale the radii here so that the first contact is made:
  if (maxInitRad) {
    MaximizeRadii();
  }


  ////////////////////////////////////////////////////////////
  //
  //  The SLP iterations
  //
  ////////////////////////////////////////////////////////////


  bool strictAfterCheck = useStrictAfter;
  double phi = sphereVol / latVol;
  if (strictAfterCheck) {
    if (phi<strictAfter)
      strictJam=0;
    else {
      strictJam=1;
      strictAfterCheck = false;
    }
  }
  LPClass LP;
  timer.Start();
  saveTimer.Start();
  while (lpIters < maxIters) {
    cout << "------------------------------------------" << endl;
    cout << "LP Iteration " << lpIters+1 << endl;
    if (lpIters > 0) {
      lastLastVol = lastVol;


      if (useNNL && (maxSingleMove > NNLextraDist/2.0)) {
	maxSingleMove = 0.0;
	cout << "Recalculating NNLs\n";
	totNeighbors = calcNNLs();
      }
    }
    lastVol = latVol;

    //Set flags:
    printThisIter_pkg = (printEvery   > 0) && ((lpIters+1) % printEvery   == 0);
    printThisIter_LP  = (printLPEvery > 0) && ((lpIters+1) % printLPEvery == 0);

    //Get transMax for the current lattice:
    //Need biggest latVec:
    double biggestLatVec=0.0;
    for (int d1=0; d1<dim; d1++) {
      double thisLatVec=0.0;
      for (int d2=0; d2<dim; d2++) {
	const double dVal=gsl_matrix_get(lambdas,d2,d1);
	thisLatVec += dVal*dVal;
      }
      if (thisLatVec>biggestLatVec)
	biggestLatVec=thisLatVec;
    }
    biggestLatVec = sqrt(biggestLatVec);
    transMax = transMaxL/biggestLatVec;

    //Run the LP routines:
    LP.LPRoutine(lpIters,totNeighbors);

    //Do some MC sweeps between iterations, if asked
    if (MCMidSweeps > 0.0) {
      int numTries = (int) (MCMidSweeps * N);
      double mc_maxDisp = MC_Sweep(numTries);
      //Re-calculate NNL if needed:
      maxSingleMove += mc_maxDisp;
      if (useNNL && (maxSingleMove > NNLextraDist/2.0)) {
	maxSingleMove = 0.0;
	cout << "Recalculating NNLs\n";
	totNeighbors = calcNNLs();
      }
    }

    latVol = getVol();
    phi = sphereVol / latVol;
    //Push back phiHist, if being used:
    if (phiHist) {
      for (int i=termPhiHist-1; i>0; i--)
	phiHist[i] = phiHist[i-1];
      phiHist[0] = phi;
    }
    cout << "  phi                = " << phi << endl;
        //Check for strict activation:
    if (strictAfterCheck && phi>=strictAfter) {
      cout<<"-----------------------Strict jamming activated!--\n";
      strictJam=1;
      strictAfterCheck = false;
    }
    bool checkTerm = CheckTermination(LP,lastLastVol,latVol,phi);
    if (checkTerm) {
      break;
    }
    lpIters++;

    if (printThisIter_pkg) {
      printSuccess = printPacking(parentDirectory + outputFilename , true);
      if (printSuccess == 0) {
	cerr << "Packing did not print for some reason at iters = " << lpIters << "\n";
      }
      else {
	cout << "Printed packing at iters = " << lpIters << "\n";
      }
    }
    //Check if we should print some save data:
    saveTimer.End();
    if (saveTimer.timePassed > 60*5) {//Save every 5 minutes
      saveTimer.Start(); //Restart the save timer
      if (autoSave) {
	SaveProgress();
      }
    }
  }//LP loop

  if (useTimer == 1) {//Take note of when the simulation started
    timer.End();
    PrintTime(timer);
  }

  if (lpIters == maxIters) {
    cout << "Terminated due to maximum iterations exceeded\n";
  }
  cout << "iterations completed = " << lpIters << "\n";
  cout << "lastLastVol          = " << lastLastVol << "\n";
  cout << "lastVol              = " << lastVol << "\n";
  cout << "latVol               = " << latVol << "\n";
  if (useTimer == 1) timer.Display();

  // print the last packing
  printSuccess = printPacking(parentDirectory + outputFilename , false);

  //If the last print was successful, then delete any temporary save info:
  if (printSuccess && autoSave) {
    ClearSaveData();
  }


  // free memory
  gsl_rng_free(RNG);
  gsl_matrix_free(lambdas);
  gsl_matrix_free(inverseLambdas);
  delete [] localCoords;
  delete [] globalCoords;
  delete [] radii;
  delete [] distTempL;
  delete [] distTempG;

  if (phiHist) {
    delete [] phiHist;
    phiHist = NULL;
  }

  if (useNNL) {
    DeleteOldNNL();
    delete [] neighborListDelta;
    delete [] neighborListOverlap;
  }


  // end program
  return 0;
}


bool ReadFlags(int    argc,
	       char **argv)
//Get the input file (allow for choosing at runtime)
{
  //Defaults:
  have_initConfigName = false;
  bool haveInFile = false;
  bool have_outputFilename = false;
  tempFolder = "";
  autoSave = false;
  int i = 1;
  while (i < argc) {
    string thisInput = argv[i];
    
    if (thisInput == "-IC") {//specify initial condition file
      //#back
      readInitFile=true;
      initConfigName = argv[i+1];
      have_initConfigName = true;
      i+=2;
    }
    else if (thisInput == "-I") {
      inputParametersFilename = argv[i+1];
      i+=2;
      haveInFile = true;
    }
    else if (thisInput == "-T") {//Specify temporary directory name
      autoSave = true;
      tempFolder = argv[i+1];
      tempFolder.append("/");
      i+=2;
    }
    else if (thisInput == "-O") {//Specify output Filename
      have_outputFilename = true;
      outputFilename = argv[i+1];
      i+=2;
    }
    else if (thisInput == "--check-LP-solve") {
      cout<<"--check-LP-solve given; we'll check the LP solver.\n";
      checkLPSolve=true;
      i++;
    }
    else {//No flag here!
      i++;
    }
  }

  if (!haveInFile) {
    cerr << "Input file not specified" << endl;
    exit(ERR_NOINPUTFILE);
  }

  return(have_outputFilename);
}



bool readInput(bool   have_outputFilename) {
  cout<<"\nReading input parameters file.\n";
  // variables
  string input;
  string token;
  ifstream inFile;

  // check variables - if this variable isn't included, post a warning
  bool Nwarn = true;
  bool dimWarn = true;
  bool parentDirectoryWarn = true; //Inside which input and output files go...
  bool initRadiiNameWarn = true;
  bool solverWarn = true;          //You need to choose what solver to use, now!
  bool haveTermCriterion = false;  //Whether we specified how to stop

  // read input file directly, line by line
  inFile.open(inputParametersFilename.c_str(),ios::in);

  if (!inFile) {
    cerr << "Can't open input file; exiting\n";
    exit(1);
  }

  while (!inFile.fail()) {//Go through the lines of the input file
    getline(inFile,input);

    if (!input.empty()) {
      stringstream inputStream(input);

      if (input[0] == '#') {//This line specifies a parameter...
	inputStream >> token;

	if (token == "#readInitFile") {
	  inputStream >> readInitFile;
	}
	else if (token == "#readInitRadii") {
	  inputStream >> readInitRadii;
	}
	else if (token == "#useNNL") {
	  inputStream >> useNNL;
	}
	else if (token == "#parentDirectory") {
	  inputStream >> parentDirectory;
	  parentDirectory.append("/");
	  parentDirectoryWarn = false;
	}
	else if (token == "#initConfigName") {
	  if (!have_initConfigName) {//In case this was specified in ReadFlags()
	    inputStream >> initConfigName;
	    have_initConfigName = true;
	  }
	}
	else if (token == "#initRadiiName") {
	  inputStream >> initRadiiName;
	  initRadiiNameWarn = false;
	}
	else if (token == "#outputFilename") {
	  string temp;
	  inputStream >> temp;
	  if (!have_outputFilename) {
	    outputFilename = temp;
	    have_outputFilename = true;
	  }
	}
	else if (token == "#N") {
	  inputStream >> N;
	  Nwarn = false;
	}
	else if (token == "#dim") {
	  inputStream >> dim;
	  dimWarn = false;
	}
	else if (token == "#maxInitRad") {
	  double tempVal;
	  inputStream >> tempVal;
	  maxInitRad = tempVal == 1;
	}
	else if (token == "#transMax") {
	  inputStream >> transMax;
	}
	else if (token == "#compMax") {
	  inputStream >> compMax;
	}
	else if (token == "#shearMax") {
	  inputStream >> shearMax;
	}
	else if (token == "#strictJam") {
	  inputStream >> strictJam;
	}
	else if (token == "#strictAfter") {
	  useStrictAfter=true;
	  inputStream >> strictAfter;
	  cout<<" strictAfter activated; crossover to strict jamming will happen at phi="<<strictAfter<<"\n";
	}
	else if (token == "#delta") {
	  inputStream >> delta;
	}
	else if (token == "#maxIters") {
	  inputStream >> maxIters;
	}
	else if (token == "#MCStartSweeps") {
	  inputStream >> MCStartSweeps;
	}
	else if (token == "#MCMidSweeps") {
	  inputStream >> MCMidSweeps;
	}
	else if (token == "#termTol") {//The minimum change in lattice volume
	                               //(between burrent iteration and iteration-before-previous, to prevent toggling)
	  inputStream >> termTol;
	}
	else if (token == "#termCriterion") {//Which termination criterion should be used
	  inputStream >> termCriterion;
	  haveTermCriterion = true;
	}
	else if (token == "#phiTerm") {//Stopping density
	  inputStream >> phiTerm;
	}
	else if (token == "#termPhiHist") {
	  inputStream >> termPhiHist;
	  if (termPhiHist>0) {
	    cout<<"Will use phi history of "<<termPhiHist<<" solves to detect termination.\n";
	    termPhiHistDecNum = (int) (termPhiHistDecFrac*(double)(termPhiHist-1));
	    if (phiHist) {//Avoid double-allocating
	      delete [] phiHist;
	      phiHist=NULL;
	    }
	    phiHist=new double[termPhiHist];
	    for (int i=0; i<termPhiHist; i++)
	      phiHist[i] = 0.0;
	  }
	}
	else if (token == "#termPhiHistDecFrac") {
	  inputStream >> termPhiHistDecFrac;
	  const double numChanges=(double)termPhiHist-1.0;
	  const double numDec = termPhiHistDecFrac*numChanges;
	  termPhiHistDecNum = (int)numDec;
	  cout<<"numChanges="<<numChanges<<"\n";
	  cout<<"numDec    ="<<numDec<<"\n";
	  cout<<"termPhiHistDecFrac = "<<termPhiHistDecFrac<<", so at most "<<termPhiHistDecNum-1<<" decreases are allowed.\n";
	}
	else if (token == "#rescaleIC") {//Rescale the IC
	  inputStream >> rescaleIC;
	}
	else if (token == "#printLPEvery") {//Write out the LP solution to file
	  inputStream >> printLPEvery;
	}
	else if (token == "#bidisperse") {
	  int temp;
	  inputStream>>temp;
	  bidisperse=temp==1;
	}
	else if (token == "#bidisperse_x") {//Number ratio
	  inputStream>>bidisperse_x;
	}
	else if (token == "#bidisperse_a") {//Size ratio
	  inputStream>>bidisperse_a;
	  if (bidisperse_a<0.0) {
	    bidisperse_a *= -1.0;
	    cerr<<"WARNING: bidisperse size ratio was negative!  (Set to "<<bidisperse_a<<")\n";
	  }
	  else if (bidisperse_a==0.0) {
	    bidisperse_a = 0.7;
	    cerr<<"WARNING: bidisperse size ratio was ZERO!  (Set to "<<bidisperse_a<<")\n";
	  }
	  if (bidisperse_a>1.0)
	    bidisperse_a = 1.0/bidisperse_a; //Ensure it's between 0 and 1
	}
	else if (token == "#randLatVecs") {
	  inputStream >> randLatVecs;
	}
	else if (token == "#maxLatLength") {
	  inputStream >> maxLatLength;
	}
	else if (token == "#minLatLength") {
	  inputStream >> minLatLength;
	}
	else if (token == "#minAngDeg") {
	  inputStream >> minAngDeg;
	}
	else if (token == "#manualMinVol") {
	  inputStream >> manualMinVol;
	}
	else if (token == "#radLatTol") {
	  inputStream >> radLatTol;
	}
	else if (token == "#topFail") {
	  inputStream >> topFail;
	}
	else if (token == "#maxVolNum") {
	  inputStream >> maxVolNum;
	}
	else if (token == "#inputPhi") {
	  inputStream >> inputPhi;
	}
	else if (token == "#overBoxes") {
	  inputStream >> overBoxes;
	}
	else if (token == "#maxBoxNum") {
	  inputStream >> maxBoxNum;
	}
	else if (token == "#randOverlapMove") {
	  inputStream >> randOverlapMove;
	}
	else if (token == "#resizeSpace") {
	  inputStream >> resizeSpace;
	}
	else if (token == "#resizeTol") {
	  inputStream >> resizeTol;
	}
	else if (token == "#NNLextraDist") {
	  inputStream >> NNLextraDist;
	}
	else if (token == "#printEvery") {
	  inputStream >> printEvery;
	}
	else if (token == "#printPrecision") {
	  inputStream >> printPrecision;
	}
	else if (token == "#useTimer") {
	  inputStream >> useTimer;
	}
	else if (token == "#scaleUnitRadius") {
	  inputStream >> scaleUnitRadius;
	}
	else if (token == "#solver") {
	  inputStream >> solver;
	  solverWarn = false;
	}
	else if (token == "#feasibleTolMin") {
	  inputStream >> feasibleTolMin;
	}
	else if (token == "#feasibleTolMax") {
	  inputStream >> feasibleTolMax;
	}
	else if (token == "#pivotTol") {
	  inputStream >> pivotTol;
	}
	else if (token == "#GLPK_PresolveVar") {
	  inputStream >> GLPK_PresolveVar;
	}
	else if (token == "#GLPK_BasisFactType") {
	  inputStream >> GLPK_BasisFactType;
	}
	else if (token == "#GRB_Method") {
	  inputStream >> GRB_Method;
	}
	else if (token == "#GRB_Presolve") {
	  inputStream >> GRB_Presolve;
	}
	else if (token == "#numThreads") {
	  inputStream >> numThreads;
	}
      }
    }
  }

  //After reading, set some things:
  feasibleTol = feasibleTolMax;

  if (readInitFile && have_initConfigName) {
    N = GetNFromPacking(initConfigName);
    Nwarn = false;
  }

  if (minAngDeg > 85.0) {
    cerr << "mininum RSA box angle in degrees #minAngDeg is greater than 85 degrees, exiting.\n";
    exit(1);
  }

  if (overBoxes > 0 && useNNL) {
    cerr << "You cannot use a nearest neighbor list (#useNNL = true) and have an overbox check (#overBoxes > 0). Exiting.\n";
    exit(1);
  }

  if (overBoxes == 0 && useNNL == 0) {
    cerr << "Warning: checking only inside the unit cell for overlap. NOT checking periodic boundary conditions!\n";
  }

  if (Nwarn) {
    cerr << "Input file does not contain the number of spheres #N!\n";
  }

  if (dimWarn) {
    cerr << "Input file does not contain the dimension #dim!\n";
  }

  if (solverWarn) {
    cerr << "Input file must specify a solver with the #solver token (default = GLPK)\n";
  }

  if (readInitFile && readInitRadii) {
    cerr << "Input file specified to read both from an input radii file and an init config file: ignoring input radii file!\n";
  }

  if (!have_initConfigName && readInitFile) {
    cerr << "Input file does not contain an init config filename #initConfigName, but was told to read an init config!\n";
  }

  if (initRadiiNameWarn && readInitRadii) {
    cerr << "Input file does not contain an init radii filename #initRadiiName, but was told to read an input radii file!\n";
  }

  if (!readInitFile && !readInitRadii) {
    cerr << "Program was told not to read an init config file or init radii file, so monodisperse spheres are assumed.\n";
  }

  if (!have_outputFilename) {
    cerr << "ouputFilename was not specified with #outputFilename nor -O flag!\n";
  }

  if (N*int(pow(2.0*double(overBoxes) +1.0,dim)) > 100000) {
    cerr << "The number of sphere images to be checked is over 100,000; this run might take a while.\n";
  }

  if (parentDirectoryWarn) {
    cerr << "You can now specify a parent directory in which input and output files go.\n";
  }

  if (!haveTermCriterion) {
    termCriterion = "latticeVol";
    cerr << "Termination criterion wasn't specified; 'latticeVol' chosen by default.\n";
  }

  inFile.close();

  // initialize the variable coordinates - necessary regardless of whether an initial config (readInitFile = true) is provided
  lambdas = gsl_matrix_calloc(dim,dim);
  localCoords = new double[N*dim];
  globalCoords = new double[N*dim];
  radii = new double[N];
  distTempL = new double[dim];
  distTempG = new double[dim];

  for (int i=0; i<N; i++) {
    radii[i] = 0.0;
    for (int d=0; d<dim; d++) {
      localCoords[dim*i +d] = 0.0;
      globalCoords[dim*i +d]= 0.0;
    }
  }

  for (int i=0; i<dim; i++) {
    distTempL[i] = 0.0;
    distTempG[i] = 0.0;
  }

  // Do bidisperse or read in the radii configuration file if necessary
  if (bidisperse) {
    const int nSmall = (int) (bidisperse_x*(double) N);
    for (int i=0; i<N-nSmall; i++)
      radii[i] = 1.0;
    for (int i=N-nSmall; i<N; i++)
      radii[i] = bidisperse_a;
  }
  else if (readInitRadii) {
    // variables
    int checkNumParticles = 0;
    string radiiFile = parentDirectory + initRadiiName + ".dat";
    inFile.open(radiiFile.c_str(),ios::in);

    if (!inFile) {
      cerr << "Can't open input radii file "<<radiiFile<<"\nexiting\n";
      exit(1);
    }

    inFile >> checkNumParticles;
    if (checkNumParticles != N) {
      cerr << "Number of particles in input file and in input radii file do not match! Exiting\n";
      exit(1);
    }

    for (int i=0; i<N; i++) {
      inFile >> radii[i];
    }

    inFile.close();
  }

  //Read in a packing if:
  //1) autoSave = true AND There is saved data in the temp location...
  //  -OR-
  //2) If the input asks to read in a packing
  bool haveTempDir = false;
  try {
    //If the temp directory exists, then look for saved data...
    haveTempDir = boost::filesystem::is_directory(parentDirectory + tempFolder);
  }
  catch (...) {}
  bool havePacking = false;
  if (haveTempDir && autoSave == true) {
    cout << "Temporary directory detected; will check for save data" << endl;
    havePacking = ReadPacking(parentDirectory + tempFolder + "SavePacking.dat");
    if (havePacking) {
      //Figure out which iteration we're starting at:
      LoadSaveData();
    }
  }
  if (readInitFile && !havePacking) {
    havePacking = ReadPacking(parentDirectory + initConfigName + ".dat");
  }

  cout<<"Done processing input parameters.\n\n";

  return(havePacking);
}


int GetNFromPacking(string initConfigName)
//Because it knows best!
{
  string inFile = parentDirectory + initConfigName + ".dat";
  ifstream fin(inFile.c_str(),ios::in);
  int packN;
  if (!fin.is_open()) {
    cerr << "Initial configuration " << inFile << " does not exist!\n";
    packN = -1;
  }
  else {
    fin.ignore(256,'\n');
    fin >> packN;
    fin.close();
  }

  return(packN);
}

bool ReadPacking(string inFilename)
{
  double val = 0.0;
  int checkNumParticles = 0;
  inverseLambdas = gsl_matrix_calloc(dim,dim);
  string input;
  ifstream inFile;

  inFile.open(inFilename.c_str(),ios::in);

  if (!inFile) {
    cerr << "Can't open init config file; exiting" << endl;
    //    exit(1);
    return(false); //Don't have a packing!
  }

  // Use the first few lines to check the parameters!
  //first some trash necessary for gsl output file
  getline(inFile,input);
  stringstream ss1(input);
  int dimTest;
  ss1 >> dimTest;
  if (dimTest != dim) {
    cerr << "WARNING: dimension disagreement between parameters file and input packing\n";
    cerr << "  (packing dim = " << dimTest << ")" << endl;
    cerr << "--Exiting." << endl;
    exit(1);
  }
  string buffer;
  ss1 >> buffer; //"HS"
  string packType;
  ss1 >> packType; //"poly" or "mono"
  getline(inFile,input); //Line 2 is junk.
  inFile >> checkNumParticles;
  if (checkNumParticles != N) {
    cerr << "Number of particles in input file and in initial config file do not match! Exiting\n";
    exit(1);
  }

  double radMono;
  if (packType == "mono") {//This line is the diameter value for monodisperse packings
    inFile >> radMono;
    radMono /= 2.0; //Convert from diameter to radius
  }

  // lattice vectors next
  for (int i=0; i<dim; i++) {
    for (int j=0; j<dim; j++) {
      inFile >> val;
      gsl_matrix_set(lambdas,j,i,val);
    }
  }

  // then more trash
  getline(inFile,input);
  getline(inFile,input);

  // then coordinates and radii
  for (int i=0; i<N; i++) {
    for (int d=0; d<dim; d++) {
      inFile >> globalCoords[dim*i +d];
    }
    if (packType == "poly") {
      inFile >> radii[i];
    }
    else {
      radii[i] = radMono;
    }
  }

  inFile.close();

  // calculate inverse
  inverseLambdas = getInverse(lambdas);

  // calculate local coordinates
  for (int i=0; i<N; i++) {
    for (int j=0; j<dim; j++) {
      for (int d=0; d<dim; d++) {
	val = gsl_matrix_get(inverseLambdas,j,d);
	localCoords[dim*i +j] = localCoords[dim*i +j] + val*globalCoords[dim*i +d];
      }
    }
  }

  for (int i=0; i<N; i++) {
    if (radii[i] > biggestRad) {
      biggestRad = radii[i];
    }
  }

  // free memory
  //gsl_matrix_free(inverseLambdas); //Happens at the end of main

  return(true); //Got a packing!
}



void RescalePacking()
{
  cout<<"Rescale IC (factor = "<<rescaleIC<<")\n";
  //Rescale lattice matrix:
  gsl_matrix_scale(lambdas,rescaleIC);
  inverseLambdas = getInverse(lambdas); //Re-compute
  //Rescale coordinates:
  int k=0;
  for (int i = 0 ; i < N ; i++) {
    for (int d = 0 ; d < dim ; d++) {
      globalCoords[k] *= rescaleIC;
      k++;
    }
  }

  //Local coordinates remain unchanged.

  return;
}


void MaximizeRadii()
//I know it's not fast, but it's not the real timesink in this program...
{
  cout<<"Maximize radii\n";

  double maxExpansion = 1.0; //Multiply the radii by this number.

  //Find the maximum allowed expansion
  if (useNNL) {
    NeighborNode *addressTempNNL = 0;
    for (int i=0; i<N; i++) {
      addressTempNNL = neighborListDelta[i];
      while (addressTempNNL) {
	int j = addressTempNNL->index;
	for (int d=0; d<dim; d++) {
	  distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d];
	  if      (distTempL[d] >  0.5) distTempL[d] -= 1.0;
	  else if (distTempL[d] < -0.5) distTempL[d] += 1.0;
	}
	double thisExp = (getGlobalLength(distTempL) - resizeSpace) / (radii[i]+radii[j]);
	if (thisExp > maxExpansion) maxExpansion = thisExp;
      }
    }
  }
  else {//No NNL
    // box variables
    int indexNum = int(pow(2.0*double(overBoxes) +1.0,dim));
    int selfIndexSkip = (indexNum -1)/2;             // this number is the self-image in the same unit cell
    double shift = 0.0;
    int quotient = 0;
    int remain = 0;
    for (int i=0; i<N; i++) {
      for (int j=i; j<N; j++) {
	for (int k=0; k < indexNum; k++) {
	  if (j==i && k == selfIndexSkip) {    // skip self image in same box
	    continue;
	  }
	  quotient = k;
	  for (int d=0; d<dim; d++) {
	    remain = quotient % (2*overBoxes +1);
	    shift = double(remain - overBoxes);        // this is the image that is shift lattice cells over
	    distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d] + shift;
	    quotient = quotient/(2*overBoxes +1);
	  }
	  double thisExp = (getGlobalLength(distTempL) - resizeSpace) / (radii[i]+radii[j]);
	  if (thisExp > maxExpansion) maxExpansion = thisExp;
	}
      }
    }
  }

  //Perform expansion:
  for (int i = 0 ; i < N ; i++)
    radii[i] *= maxExpansion;

  return;
}


gsl_matrix *getInverse(gsl_matrix *matrixToInvert) {
  // check to see if matrix is square
  if (matrixToInvert->size1 != matrixToInvert->size2) {
    printf("This matrix is not square, exiting\n");
    exit(1);
  }

  // variables needed
  int matrixSize = matrixToInvert->size1;
  int permInt = 0;                                             		       // necessary for gsl inverse calculation
  int successLU = 0;                                           			   // returns the success of the LU decomposition and inverse calc
  gsl_permutation *inverseP = gsl_permutation_calloc(matrixSize);            // necessary for gsl inverse calculation
  gsl_matrix *LUdecomp = gsl_matrix_calloc(matrixSize,matrixSize);           // necessary for the gsl inverse calculation
  gsl_matrix *inverseMatrix = gsl_matrix_calloc(matrixSize,matrixSize);      // the inverse matrix

  // calculate inverse
  gsl_matrix_memcpy(LUdecomp,matrixToInvert);

  successLU = gsl_linalg_LU_decomp(LUdecomp,inverseP,&permInt);
  if (successLU == 1) {
    cerr << "Inverse calculation of the lambdas matrix failed at LU decomposition\n";
  }
  successLU = gsl_linalg_LU_invert(LUdecomp,inverseP,inverseMatrix);
  if (successLU == 1) {
    cerr << "Inverse calculation of the lambdas matrix failed at inverse calculation\n";
  }

  // memory free
  gsl_matrix_free(LUdecomp);
  gsl_permutation_free(inverseP);

  // returns
  return inverseMatrix;
}



void getRSAbox() {
  // variables
  double volume = 0.0;
  double vecLength = 0.0;
  double newVecLength = 0.0;
  double angle = 0.0;
  double minAngle = minAngDeg*(PI/180.0);          // minimum angle between lattice vectors, stated in radians
  int volNum = 0;                                  // counter for failed attempts to create RSA box

  // set first vector to (1,0...0)
  gsl_matrix_set(lambdas,0,0,1.0);

  // make no more than maxVolNum attempts to find an RSA box
  while (volNum < maxVolNum) {
    int j = 1;

    // number of random elements in lattice vector j is equal to j +1
    while (j < dim) {
      // calculate random vector and its length
      vecLength = 0.0;
      for (int i=0; i<=j; i++) {
	gsl_matrix_set(lambdas,i,j,gsl_rng_uniform_pos(RNG));
	vecLength = vecLength + gsl_matrix_get(lambdas,i,j)*gsl_matrix_get(lambdas,i,j);
      }
      vecLength = sqrt(vecLength);

      // resize vector
      newVecLength = (maxLatLength - minLatLength)*gsl_rng_uniform_pos(RNG) + minLatLength;
      for (int i=0; i<=j; i++) {
	gsl_matrix_set(lambdas,i,j,(newVecLength/vecLength)*gsl_matrix_get(lambdas,i,j));
      }

      // check to ensure angle between new vec and all old vecs is greater than minAngle
      int i = 0;
      while (i < j) {
	angle = getAngle(i,j);     // gets the angle between lambdas matrix lattice vectors i and j

	if (angle < minAngle) {
	  break;
	}
	else {
	  i = i +1;
	}
      }

      // increment j iff all angles b/t the new vector and the old ones is less than minAngle
      if (i == j) {
	j = j + 1;
      }
    }

    if (manualMinVol > 0.0) {
      volume = getVol();            // gets the volume of lambdas matrix lattice vectors
      if (volume < manualMinVol) {
	volNum = volNum + 1;
      }
      else {
	break;
      }
    }
    else {
      break;
    }
  }
}



double getAngle(int i, int j) {
  // variables
  double angle = 0.0;
  double vecInorm = 0.0;
  double vecJnorm = 0.0;

  // calculate |i|, |j|, and i dot j
  for (int d=0; d<dim; d++) {
    angle = angle + gsl_matrix_get(lambdas,d,i)*gsl_matrix_get(lambdas,d,j);
    vecInorm = vecInorm + gsl_matrix_get(lambdas,d,i)*gsl_matrix_get(lambdas,d,i);
    vecJnorm = vecJnorm + gsl_matrix_get(lambdas,d,j)*gsl_matrix_get(lambdas,d,j);
  }
  vecInorm = sqrt(vecInorm);
  vecJnorm = sqrt(vecJnorm);

  angle = acos(angle/(vecInorm * vecJnorm));

  // returns
  return angle;
}



double getVol() {//Gets the volume of the fundamental cell
  // variables
  double volume = 0.0;
  int permInt = 0;                                             		       // necessary for gsl LU decomp and gsl determinant
  int successLU = 0;                                           			   // returns the success of the LU decomposition
  gsl_permutation *inverseP = gsl_permutation_calloc(dim);            	   // necessary for gsl LU decomp
  gsl_matrix *LUdecomp = gsl_matrix_calloc(dim,dim);          			   // necessary for gsl LU decomp

  gsl_matrix_memcpy(LUdecomp,lambdas);

  successLU = gsl_linalg_LU_decomp(LUdecomp,inverseP,&permInt);
  if (successLU == 1) {
    cerr << "Inverse calculation of the lambdas matrix failed at LU decomposition\n";
  }

  volume = gsl_linalg_LU_det(LUdecomp, permInt);

  // memory free
  gsl_matrix_free(LUdecomp);
  gsl_permutation_free(inverseP);

  // returns
  return fabs(volume);
}



void setSphereRadii() {
  // variables
  double vecLength = 0.0;
  double smallestVec = 1.0e12;     // function won't work if any lattice vec is larger than this value
  double maxSphereRad = 0.0;
  double initBiggestRad = 0.0;
  double latVol = 0.0;
  double sphereVol = 0.0;
  double sphereVolConst = 0.0;
  double sphereRadReductionFactor = 0.0;   // the factor by which to reduce the radii s.t. phi = inputPhi

  // finds maximum radius of largest sphere according to the lattice and the parameter radLatTol
  for (int j=0; j<dim; j++) {
    vecLength = 0.0;
    for (int i=0; i<dim; i++) {
      vecLength = vecLength + gsl_matrix_get(lambdas,i,j)*gsl_matrix_get(lambdas,i,j);
    }
    if (vecLength < smallestVec) {
      smallestVec = vecLength;
    }
  }
  smallestVec = sqrt(smallestVec);
  maxSphereRad = radLatTol*smallestVec;

  sphereVolConst = pow(PI,dim/2.0)/gsl_sf_gamma(dim/2.0 +1.0);
  latVol = getVol();

  if (readInitRadii || bidisperse) {
    // this is the case when radii have been read in
    for (int i=0; i<N; i++) {
      sphereVol += sphereVolConst*pow(radii[i],dim);     // calculates total volume of spheres
      if (radii[i] > initBiggestRad) {
	initBiggestRad = radii[i];
      }
    }

    sphereRadReductionFactor = pow((inputPhi*latVol)/sphereVol,1.0/dim);
    biggestRad = min(initBiggestRad*sphereRadReductionFactor,maxSphereRad);
    sphereRadReductionFactor = biggestRad/initBiggestRad;

    if (biggestRad == maxSphereRad) {
      cerr << "Due to #radLatTol and a large biggest sphere vs. smallest lattice vector, new inputPhi is " << sphereVol*pow(sphereRadReductionFactor,dim) << "\n";
    }

    for (int i=0; i<N; i++) {
      radii[i] = radii[i]*sphereRadReductionFactor;
    }
  }
  else {// this is the monodisperse case where no radii have been read in
    initBiggestRad = pow((inputPhi*latVol)/(double(N)*sphereVolConst),1.0/dim);
    biggestRad = min(initBiggestRad,maxSphereRad);

    if (biggestRad == maxSphereRad) {
      cerr << "Due to #radLatTol and small smallest lattice vector, new inputPhi is " << sphereVolConst*double(N)*pow(biggestRad,dim)/latVol  << "\n";
    }
    for (int i=0; i<N; i++) {
      radii[i] = biggestRad;
    }
  }

  if (scaleUnitRadius) {
    cout << "Scale the packing to unit radii" << endl;
    //Rescale the packing so that the smallest sphere in the packing has radius 1.
    //1) Find the smalelst radius
    double smallestRad = 1.0;
    bool   foundSmallest = false; //To make sure this was done correctly
    while (!foundSmallest) {
      smallestRad *= 10.0;
      for (int i = 0 ; i < N ; i++) {
	if (radii[i] < smallestRad) {
	  foundSmallest = true;
	  smallestRad = radii[i];
	}
      }
    }
    cout << "--Smallest radius was " << smallestRad << endl;
    //2) Rescale:
    double scaleFactor = 1.0 / smallestRad;
    //2.1) Spheres:
    biggestRad *= scaleFactor;
    for (int i = 0 ; i < N ; i++) {
      radii[i] *= scaleFactor;
      //cout << "  radii[" << i << "] = " << radii[i] << endl;
    }
    //2.2) Box:
    gsl_matrix_scale(lambdas,scaleFactor);
    for (int j = 0 ; j < dim ; j++) {
      for (int i = 0 ; i < dim ; i++) {
	cout << "  lambda("<<i<<","<<j<<") = " << gsl_matrix_get(lambdas,i,j) << endl;
      }
    }
  }
  
}


double getSphereVol()
//Gets the total volume of the spheres, sphereVol
//phi = sphereVol / latVol
{
  double sphereVol = 0.0;
  double sphereVolConst = pow(PI,dim/2.0)/gsl_sf_gamma(dim/2.0 +1.0);

  for (int i = 0 ; i < N ; i++) {
    sphereVol += sphereVolConst * pow(radii[i],dim);
  }

  return(sphereVol);
}


void placeSpheres()
//The RSA function
{
  // variables
  double dist = 0.0;
  double shift = 0.0;
  int quotient = 0;
  int remain = 0;
  int failCount = 0;
  int indexNum = int(pow(2.0*double(overBoxes) +1.0,dim));
  int selfIndexSkip = (indexNum -1)/2;              // this number is the self-image in the same unit cell
  int j = 0;

  int i = 0;
  while (i < N) {
    for (int d=0; d<dim; d++) {
      localCoords[dim*i +d] = gsl_rng_uniform_pos(RNG);
    }

    if (overBoxes > 0) {
      // this is the case where all images are checked (including self-overlap)
      j = 0;
      while (j <= i) {
	for (int k=0; k < indexNum; k++) {
	  if (j==i && k == selfIndexSkip) {    // skip self image in same box
	    continue;
	  }
	  quotient = k;
	  for (int d=0; d<dim; d++) {
	    remain = quotient % (2*overBoxes +1);
	    shift = double(remain - overBoxes);        // this is the image that is shift lattice cells over
	    distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d] + shift;
	    quotient = quotient/(2*overBoxes +1);
	  }

	  dist = getGlobalLength(distTempL);

	  if (dist < radii[i] + radii[j]) {             // note that this is for additive diameters!
	    failCount = failCount + 1;
	    j = N +1;
	    break;
	  }
	}

	// increment j unless j indicates failure (j = N + 1 is failure)
	if (j < N) {
	  j = j +1;
	}
      }

      if (j == i +1) {        // this only occurs if no overlaps at all have been found
	i = j;
	failCount = 0;      // reset the fail count
      }
    }
    else {
      // this is the case where L/2 convention is used
      j = 0;
      while (j < i) {
	for (int d=0; d<dim; d++) {
	  distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d];
	  if (distTempL[d] > 0.5) {
	    distTempL[d] = distTempL[d] - 1.0;
	  }
	  else if (distTempL[d] < -0.5) {
	    distTempL[d] = distTempL[d] + 1.0;
	  }
	}

	dist = getGlobalLength(distTempL);

	if (dist < radii[i] + radii[j]) {             // note that this is for additive diameters!
	  failCount = failCount + 1;
	  break;
	}
	else {
	  j = j +1;      // increment j if dist >= the above "if" statement
	}
      }

      if (j == i) {        // this only occurs if no overlaps at all have been found
	i = i +1;
	failCount = 0;      // reset the fail count
      }
    }

    if (failCount == topFail) {
      cerr << "Failure to place all spheres in RSA: spheres placed = " << i-1 << ", failCount = " << failCount << "\n";
      exit(1);
    }
  }
}

double getGlobalLength(double *inputVec) {
  // variables
  double dist = 0.0;

  for (int l=0; l<dim; l++) {
    distTempG[l] = 0.0;
    for (int d=0; d<dim; d++) {
      distTempG[l] = distTempG[l] + gsl_matrix_get(lambdas,l,d)*distTempL[d];    // calculate Lambda*localVec = global vec
    }
    dist = dist + distTempG[l]*distTempG[l];    // calculate square of global component
  }
  dist = sqrt(dist);

  // returns
  return dist;
}

double getMinHeight() {
  // variables
  int d = 0;
  int count = 0;
  int successQR = 0;
  double minHeight = 1000000.0;
  double height = 0.0;
  gsl_matrix *subMatLambdas = gsl_matrix_calloc(dim,dim-1);
  gsl_matrix *qUnpack = gsl_matrix_calloc(dim,dim);
  gsl_matrix *rUnpack = gsl_matrix_calloc(dim,dim-1);
  gsl_vector *tau = gsl_vector_calloc(dim-1);
  gsl_vector *getVecInt = gsl_vector_calloc(dim);

  // compute the dim heights of the unit cell defined by lambdas
  for (int i=0; i<dim; i++) {
    // start by copying all but one row of lambdas into subMatLambdas
    d = 0;
    count = 0;
    while (d < dim) {
      if (d == i) {
	count = count +1;
	d = d +1;
	continue;
      }
      gsl_matrix_get_col(getVecInt,lambdas,d);
      gsl_matrix_set_col(subMatLambdas,d -count,getVecInt);

      d = d +1;
    }

    // next do the QR calcs
    successQR = gsl_linalg_QR_decomp(subMatLambdas,tau);
    if (successQR == 1) {
      cerr << "QR decomp of the lambdas submatrix failed\n";
    }

    successQR = gsl_linalg_QR_unpack(subMatLambdas,tau,qUnpack,rUnpack);
    if (successQR == 1) {
      cerr << "QR decomp of the lambdas submatrix failed at unpack\n";
    }

    // now compute the dot product of excluded lambda vec i with the last column of Q
    height = 0.0;
    for (d=0; d<dim; d++) {
      height = height + gsl_matrix_get(qUnpack,d,dim-1)*gsl_matrix_get(lambdas,d,i);
    }
    height = fabs(height);

    if (height < minHeight) {
      minHeight = height;
    }
  }


  // free memory
  gsl_matrix_free(subMatLambdas);
  gsl_matrix_free(qUnpack);
  gsl_matrix_free(rUnpack);
  gsl_vector_free(tau);
  gsl_vector_free(getVecInt);

  // returns
  return minHeight;
}

int calcNNLs() {
  // variables
  NeighborNode *addressTempNNL = 0;
  double dist = 0.0;
  int totNeighbors = 0;    // total number of neighbor contacts (e.g., if 6 neighbors per particle, this is 3*N)

  // ensure deletion
  DeleteOldNNL();

  // calculate neighbor lists
  for (int i=0; i<N; i++) {
    for (int j=0; j<N; j++) {
      // eliminate self-neighbor
      if (i == j) {
	continue;
      }

      // use the L/2 method to calculate distance
      for (int d=0; d<dim; d++) {
	distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d];
	if (distTempL[d] > 0.5) {
	  distTempL[d] = distTempL[d] - 1.0;
	}
	else if (distTempL[d] < -0.5) {
	  distTempL[d] = distTempL[d] + 1.0;
	}
      }

      dist = getGlobalLength(distTempL);

      // create the two neighbor lists
      if (dist <= delta + radii[i] + radii[j] + NNLextraDist) {
	// the first distance check is for the inclusion sphere
	totNeighbors = totNeighbors +1;
	// add a node at the beginning of the list
	addressTempNNL = neighborListDelta[i];
	neighborListDelta[i] = new NeighborNode;
	neighborListDelta[i]->next = addressTempNNL;
	neighborListDelta[i]->index = j;

	// now the neighborList for overlap calc
	if (dist <= radii[i] + radii[j] + NNLextraDist) {
	  addressTempNNL = neighborListOverlap[i];
	  neighborListOverlap[i] = new NeighborNode;
	  neighborListOverlap[i]->next = addressTempNNL;
	  neighborListOverlap[i]->index = j;
	}
      }
    }
  }

  // returns
  return totNeighbors/2;
}

void DeleteOldNNL()
{
  for (int i=0; i<N; i++) {
    if (neighborListDelta[i] != 0) {
      delete neighborListDelta[i];
      neighborListDelta[i] = 0;
    }
    if (neighborListOverlap[i] != 0) {
      delete neighborListOverlap[i];
      neighborListOverlap[i] = 0;
    }
  }
}

int resizeIfOverlap(bool randOver) {
  // variables
  int resizeSuccess = 0;           // a "success" (1) means that a resize was performed
  double dist = 0.0;
  double resize = 0.0;
  double maxResize = 0.0;
  double maxOverlap = 0.0;
  //double storeResizeDist = 0.0;
  int i,j = 0;
  NeighborNode *addressTempNNL = 0;
  double shift = 0.0;
  int quotient = 0;
  int remain = 0;
  int indexNum = int(pow(2.0*double(overBoxes) +1.0,dim));
  int selfIndexSkip = (indexNum -1)/2;              // this number is the self-image in the same unit cell
  double *randGlobalMovement = 0;
  double *globalPos = 0;

  if (useNNL) {
    // use the L/2 method if an NNL is in use
    for (i=0; i<N; i++) {
      addressTempNNL = neighborListOverlap[i];
      while (addressTempNNL) {
	j = addressTempNNL->index;
	if (i > j) {
	  addressTempNNL = addressTempNNL->next;
	  continue;
	}
	for (int d=0; d<dim; d++) {
	  distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d];
	  if (distTempL[d] > 0.5) {
	    distTempL[d] = distTempL[d] - 1.0;
	  }
	  else if (distTempL[d] < -0.5) {
	    distTempL[d] = distTempL[d] + 1.0;
	  }
	}

	dist = getGlobalLength(distTempL);
	double overlap = radii[i] + radii[j] - (dist + resizeTol);
	// if the distance is less than the sum of the radii, then calculate and store the resize factor (resize)
	//if (dist + resizeTol < radii[i] + radii[j]) {
	if (overlap > 0) {
	  resize = ((radii[i] + radii[j])*(1.0 + resizeSpace))/dist;
	  if (resize > maxResize) {
	    maxResize = resize;
	    //storeResizeDist = dist;
	  }
	  if (overlap > maxOverlap) {maxOverlap = overlap;}
	}
	addressTempNNL = addressTempNNL->next;
      }
    }
  }//end of UseNNL if-statement
  else {//no NNL
	// calculate all (2*overBoxes +1)^dim unit cell images in the overBox method
    for (i=0; i<N; i++) {
      for (j=i; j<N; j++) {
	for (int k=0; k < indexNum; k++) {
	  if (j==i && k == selfIndexSkip) {    // skip self image in same box
	    continue;
	  }
	  quotient = k;
	  for (int d=0; d<dim; d++) {
	    remain = quotient % (2*overBoxes +1);
	    shift = double(remain - overBoxes);        // this is the image that is shift lattice cells over
	    distTempL[d] = localCoords[dim*i + d] - localCoords[dim*j + d] + shift;
	    quotient = quotient/(2*overBoxes +1);
	  }

	  dist = getGlobalLength(distTempL);
	  double overlap = radii[i] + radii[j] - (dist + resizeTol);
	  //if (dist + resizeTol < radii[i] + radii[j]) {// note that this is for additive diameters!
	  if (overlap > 0) {
	    resize = ((radii[i] + radii[j])*(1.0 + resizeSpace))/dist;
	    if (resize > maxResize) {
	      maxResize = resize;
	      //storeResizeDist = dist;
	    }
	    if (overlap > maxOverlap) {maxOverlap = overlap;}
	  }
	}
      }
    }
  }

  // rescale the lambdas matrix lattice vectors by maxResize so that no detected overlap is present
  if (maxResize > 0.0) {
    cout << "  resizeTol requests pack resizing (maxOverlap = " << maxOverlap << ")" << endl;
    resizeSuccess = 1;

    // if no random overlap is desired, then simply rescale so that farthest overlap is now contacting
    if (!randOver) {
      maxResize /= (1.0 + resizeSpace);
    }

    // rescale the lambdas matrix
    //gsl_matrix_scale(lambdas,maxResize + termTol); //Original--CAN'T USE termTol!!!
    //gsl_matrix_scale(lambdas,maxResize + resizeTol);
    gsl_matrix_scale(lambdas,maxResize);

    // if stochastic moves are used, then move spheres around a little after resize
    if (randOverlapMove && randOver) {
      // variables
      randGlobalMovement = new double[dim];
      globalPos = new double[dim];
      double randLength = 0.0;
      //gsl_matrix *inverseLambdas = gsl_matrix_calloc(dim,dim);

      // get the inverse of lambdas
      inverseLambdas = getInverse(lambdas);

      // get the random movement
      for (i=0; i<N; i++) {
	randLength = 0.0;
	for (int d=0; d<dim; d++) {
	  randGlobalMovement[d] = 2.0*(gsl_rng_uniform_pos(RNG) - 0.5);
	  randLength = randLength + randGlobalMovement[d]*randGlobalMovement[d];
	}
	randLength = sqrt(randLength);

	// get the new global position
	for (int d=0; d<dim; d++) {
	  globalPos[d] = 0.0;
	  for (j=0; j<dim; j++) {
	    globalPos[d] = globalPos[d] + gsl_matrix_get(lambdas,d,j)*localCoords[dim*i +j];
	  }
	  globalPos[d] = globalPos[d] + ((radii[i]*resizeSpace)/randLength)*randGlobalMovement[d];
	}

	// replace local coordinates with converted global coordinates
	for (int d=0; d<dim; d++) {
	  localCoords[dim*i +d] = 0.0;
	  for (j=0; j<dim; j++) {
	    localCoords[dim*i +d] = localCoords[dim*i +d] + gsl_matrix_get(inverseLambdas,d,j)*globalPos[j];
	  }
	  if (localCoords[dim*i +d] >= 1.0) {
	    localCoords[dim*i +d] = localCoords[dim*i +d] -1.0;
	  }
	  else if (localCoords[dim*i +d] < 0.0) {
	    localCoords[dim*i +d] = localCoords[dim*i +d] +1.0;
	  }
	}
      }

      // deletions
      delete [] randGlobalMovement;
      delete [] globalPos;
    }
  }

  // returns
  return resizeSuccess;
}


bool CheckTermination(LPClass &LP,
		      double   lastLastVol,
		      double   latVol,
		      double   phi)
{
  if (phi >= phiTerm) {//No exceptions to this!
    cout << "Terminate due to maximum density being met\n";
    return(true);
  }

  //The following get overridden if the LP algorithm was the barrier method
  // and was returning-sub-optimal solves due to an iteration limit
  bool terminate = false;
  if (termCriterion == "latticeVol") {
    if (fabs(lastLastVol - latVol) <= termTol) {
      cout << "Terminate due to failure to decrease volume over 2 runs\n";
      terminate = true;
    }
  }
  else if (termCriterion == "maxDisp") {
    if (maxDisp < termTol) {
      cout << "Terminate due to particle movements being too small\n";
      terminate = true;
    }
  }

  //If we've signaled for termination, but feasibleTol hasn't been brought down to feasibleTolMin, then keep decreasing it and continue:
  if (terminate && feasibleTol > feasibleTolMin) {
    cout<<" Decrease feasibleTol and continue\n";
    feasibleTol /= 10.0;
    if (feasibleTol < feasibleTolMin)
      feasibleTol = feasibleTolMin;
    cout<<"  new value = "<<feasibleTol<<"\n";
    terminate=false;
  }

  /*
  //Use the density histogram to detect if the Barrier algorithm needs more iterations:
  if (!terminate && BarIterLimit>0) {
    if (!terminate && phiHist) {//Check phiHist for density decreases:
      int numDec=0;
      for (int i=1; i<termPhiHist && numDec < termPhiHistDecNum; i++) {
	const double thisChange=phiHist[i-1]-phiHist[i];
	if (thisChange<0)
	  numDec++;
	//cout<<"  "<<thisChange<<"\n";
      }
      cout<<"  numDec = "<<numDec<<"\n";
      if (numDec>=termPhiHistDecNum) {
	cout<<termPhiHistDecNum<<" or more density decreases found in the last "<<termPhiHist<<" solves; signaling for termination.\n";
	terminate=true;
      }
    }
  }
  if (terminate && LP.SubOptimalBecauseSolverIterLimit() && iterLimitRefine>0) {
    cout << "Increase BarIterLimit and continue.\n";
    BarIterLimit += iterLimitRefine;
    if (BarIterLimit >= GRB_MAXINT) {
      BarIterLimit = GRB_MAXINT;
      iterLimitRefine = 0;
    }
    LP.BarIterLimit_flag = true;
    terminate = false;
  }
  */

  return(terminate); //No termination criteria were met
}

int printPacking(string thisOutputFilename,
		 bool addIterNum)
{
  cout << "Printing packing..." << endl;
  // variables
  ofstream outFile;
  int success = 0;
  double globalVal = 0.0;
  //string thisOutputFilename = parentDirectory + outputFilename;
  stringstream intConvert;

  if (addIterNum) {
    intConvert << lpIters;
    thisOutputFilename.append("_");
    thisOutputFilename.append(intConvert.str());
  }

  // open file
  thisOutputFilename.append(".dat");
  cout << "  print location = " << thisOutputFilename << endl;
  outFile.open(thisOutputFilename.c_str(),ios::out);

  if (!outFile.is_open()) {
    cerr << "Can't create output file " << thisOutputFilename << endl;
    return success;
  }

  //Test for monodisperse -vs- polydisperse packing:
  double radVal = radii[0];
  bool monoPacking = true;
  for (int i = 1 ; i < N ; i++) {if (radii[i] != radVal) {monoPacking = false; break;}}

  // set the output precision
  outFile.precision(printPrecision);

  // print the packing (Alek's format)
  if (monoPacking) {
    cout << "Printing monodisperse packing format" << endl;
    outFile << dim << "\t HS\t mono" << endl;
  }
  else {
    outFile << dim << "\t HS\t poly" << endl;
  }
  outFile << N << "\t" << 1 << endl;
  outFile << N << endl;
  if (monoPacking) {outFile << 2.0 * radVal << endl;}
  //Lattice matrix:
  for (int i=0;i<dim;i++) {
    for (int j=0; j<dim; j++) {
      outFile << gsl_matrix_get(lambdas,j,i) << "\t";
    }
    outFile << endl;
  }
  for (int i=0; i<dim; i++) {
    outFile << "T\t";
  }
  outFile << endl;
  //Sphere loop:
  for (int i=0; i<N; i++) {
    for (int d=0; d<dim; d++) {
      globalVal = 0.0;
      for (int l=0; l<dim; l++) {
	globalVal = globalVal + gsl_matrix_get(lambdas,d,l)*localCoords[dim*i +l];    // calculate Lambda*localVec = global vec
      }
      outFile << globalVal << "\t";
    }
    if (!monoPacking) {outFile << radii[i];}
    outFile << endl;
  }

  outFile.close();

  // returns
  success = 1;
  return success;
}


void LoadSaveData()
{
  cout << "Loading save data" << endl;
  
  ifstream inFile;
  inFile.open((parentDirectory + tempFolder + "SaveInfo.txt").c_str() , ios::in);
  if (!inFile.is_open()) {
    cout << "Failed to retrieve save data; starting from iteration 1." << endl;
    return;
  }
  else {
    string input;
    while (!inFile.fail()) {//Go through the lines of the input file
      cout << "  Get line..." << endl;
      getline(inFile,input);

      if (!input.empty()) {
	stringstream inputStream(input);
	string token;

	if (input[0] == '#') {//This line specifies a parameter...
	  inputStream >> token;
	  cout << "    " << token << endl;

	  if (token == "#lastIteration") {
	    inputStream >> lpIters;
	    cout << "Resume from iteration " << lpIters << endl;
	  }
	}
      }
    }
  }

  inFile.close();

  return;
}


void SaveProgress()
//How to check for existence of a directory
//How to make a directory
{
  cout << "Saving progress..." << endl;

  //Figure out if there's a TEMP Directory in the current parent directory
  bool haveFolder = false;
  try {
    haveFolder = boost::filesystem::is_directory(parentDirectory + tempFolder);
  }
  catch(...) {
    cout << "Directory doesn't exist" << endl;
    haveFolder = false;
  }
  //bool haveFolder = true;

  if (!haveFolder) {
    cout << "Making directory " << parentDirectory << tempFolder << endl;
    if (boost::filesystem::create_directory(parentDirectory + tempFolder) == 0) {
      cerr << "ERROR CREATING DIRECTORY FOR SAVE INFO" << endl;
    }
  }
  else {
    cout << "Temporary save data directory already exists" << endl;
  }

  //Write the file there:
  printPacking(parentDirectory + tempFolder + "SavePacking" , false); //appends ".dat" automatically

  //Write save log:
  cout << "Writing save log..." << endl;
  ofstream outFile;
  string saveLogName = parentDirectory + tempFolder + "SaveInfo.txt";
  outFile.open(saveLogName.c_str(), ios::out);
  if (!outFile.is_open()) {
    cerr << "Unable to open Save info file at " << saveLogName << endl;
  }
  else {
    outFile << "//Automatically-saved data\n";
    outFile << "#lastIteration\t" << lpIters << endl;
    outFile.close();
  }

  return;
}



void ClearSaveData()
//Clear out the temporary save information since we made it to the end of the program!
{
  cout << "Clearing temporary save data" << endl;

  if (tempFolder.empty()) {//No directory?  no clear!
    cout << "tempFolder is an empty string; don't try to delete.\n";
    return;
  }

  try {
    if (boost::filesystem::is_directory(parentDirectory + tempFolder)) {
      if (boost::filesystem::remove_all(parentDirectory + tempFolder) == 0) {
	cerr << "Error deleting temporary save data" << endl;
      }
    }
    else {
      cout << "Temporary save data doesn't exist; skipping\n";
    }
  }
  catch (...) {
    cout << "Temporary save data doesn't exist; skipping\n";
  }

  return;
}



void PrintTime(TimerClass timer)
{
  cout << "Printing Timer results..." << endl;
  //Get the file:
  ofstream outFile;
  string timerFile = "TIMEFILE.txt";

  outFile.open(timerFile.c_str(),ios::out | ios::app);

  if (outFile.is_open()) {
    outFile << timer.timePassed << endl;
    outFile.close();
    cout << "Success!" << endl;
  }
  else {
    cerr << "ERROR: could not write to " << timerFile << endl;
  }

  return;
}
